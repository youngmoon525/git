package pack06_TestList;

import java.util.ArrayList;

public class BookMain {
	public static void main(String[] args) {
		System.out.println("도서 프로그램을 시작하겠습니다");
		ArrayList<BookDTO> list = new ArrayList<BookDTO>();
		list.add(new BookDTO("혼공자", "신용권", "한빛미디어", 30000));
		list.add(new BookDTO("흔한남매8", "백난도", "아이세움", 13500));
		list.add(new BookDTO("완전한 행복", "정유정", "은행나무출판사", 15000));
		BookDAO dao = new BookDAO();
		while(true) {
			System.out.println("1. 관리자 모드   2. 사용자 모드  ▶ 그 외 키를 누르면 종료 됩니다");
			String inputData = dao.rtnString();
			if(inputData.equals("1")) {//관리자 모드
				MasterBook mb = new MasterBook();
				list = mb.mstbook(list);
			}else if(inputData.equals("2")) {//사용자 모드
				UserBook ub = new UserBook();
				ub.usBook(list);
				
			}else {
				System.out.println("프로그램을 종료합니다.");
				break;
			}
		}//while
		
		
	}//main
}
