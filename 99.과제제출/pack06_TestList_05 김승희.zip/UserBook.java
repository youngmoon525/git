package pack06_TestList;

import java.util.ArrayList;


public class UserBook {
	int coin; // iv (전역변수) 필드
	public void usBook(ArrayList<BookDTO>list ) {
		BookDAO dao= new BookDAO();
		System.out.println("사용자 모드");
		dao.display(list);
		System.out.println("금액을 입력해주세요.");
		coin = dao.rtnInt();

		System.out.println("책을 선택해 주세요.");
		int num = dao.rtnInt() - 1 ;
		
	    System.out.println("수량을 입력해주세요");
		int cnt=dao.rtnInt();
		
		if(coin >= (list.get( num).getPrice()*cnt)) {
			coin= coin-(list.get( num).getPrice()*cnt);
			System.out.println("돈을 다시 입력하세요 잔돈을 배출 합니다.");
		    System.out.println("잔돈" + coin);
		}else {
			System.out.println("잔액이 부족합니다");		
		}
        
		

	}
}


			



		
