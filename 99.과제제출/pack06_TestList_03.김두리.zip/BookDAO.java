package pack06_TestList;

import java.util.ArrayList;
import java.util.Scanner;

public class BookDAO {
	public void bookList(ArrayList<BookDTO> list) {
		for (int i = 0; i < list.size(); i++) {
			System.out.println(list.get(i).getTitle() + ", " + list.get(i).getName()
					 + ", " + list.get(i).getCompany() + ", " + list.get(i).getPrice() + "��");
		}
	}//bookList
	
	public static void main(String[] args) {
		BookDAO dao = new BookDAO();
		System.out.println(dao.rtnString());
	}
	
	public String rtnString() {
		Scanner sc = new Scanner(System.in);
		String rtnStr = "";
		while(true) {
			rtnStr = sc.nextLine();
			if (rtnStr.trim().length() > 0) {
				return rtnStr;
			}
		}
	}//rtnString
	
	public int rtnInteger() {
		Scanner sc = new Scanner(System.in);
		int rtnInt = 0;
		while(true) {
			try {
				rtnInt = Integer.parseInt(sc.nextLine());
				return rtnInt;
			} catch (Exception e) {
				System.out.println("���ڸ� �Է����ּ���");
			}
		}
	}//rtnInteger
	
	
	
	
}
