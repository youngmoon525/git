package pack06_TestList;

import java.util.ArrayList;

public class BookUser {
		public void bookUser(ArrayList<BookDTO> list) {
			System.out.println("사용자 모드를 실행합니다 1.책 구입 2.책 주문 ");
			BookDAO dao = new BookDAO();
			while (true) {
				int mode = dao.rtnInt();
				if (mode == 1) {
					System.out.println("책을 구입합니다");
					dao.change(list);
				} else if(mode == 2) {
					System.out.println("책을 주문 합니다");
					dao.oder(list);
					
				}else {
					System.out.println("올바른 번호를 선택하세요");
					break;
				}
			}
		}
}
