package pack06_TestList;

import java.util.ArrayList;

public class Bookmain {
	public static void main(String[] args) {
		ArrayList<BookDTO> list = new ArrayList<BookDTO>();
		list.add(new BookDTO("1.해리포터와 자바시간", "롤링 j", "호그컴퓨터학원", 29800));
		list.add(new BookDTO("2.코딩125시간 실화인가?", "빌게이츠", "호그컴퓨터학원", 15500));
		list.add(new BookDTO("3.전기차는 자바로", "일론 머스크", "호그컴퓨터학원", 15500));
		list.add(new BookDTO("4.혜민스님 풀소유", "우리끼리","호그컴퓨터학원", 27500));
		
		BookDAO dao = new BookDAO();
		
	
		
		while (true) {
			System.out.println("1.관리자모드 2.사용자모드 그외.시스템 종료");
			String mod = dao.rtnString();
			if (mod.equals("1")) {
				BookCRUD crud = new BookCRUD();
				crud.BookCrud(list);
			}else if (mod.equals("2")){
				BookUser user = new BookUser();
				user.bookUser(list);
			}else {
				System.out.println("시스템 종료");
				break;
			}
		}
	}
}
