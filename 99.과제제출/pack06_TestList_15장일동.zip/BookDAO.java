package pack06_TestList;

import java.io.DataOutput;
import java.util.ArrayList;
import java.util.Scanner;

public class BookDAO {
	Scanner sc = new Scanner(System.in);

	public void BookLsit(ArrayList<BookDTO> list) {
		for (int i = 0; i < list.size(); i++) {
			System.out.println(list.get(i).getTitle() + ". \n(" + list.get(i).getWriter() + "),"
					+ list.get(i).getCompany() + ",(" + list.get(i).getPrice() + ")\n");
		}
	}
//	public String onlyString() {
//		String onlyString= "";
//		while (true) {
//			try {
//			} catch (Exception e) {
//				onlyString = sc.nextLine();
//				Integer.parseInt(onlyString);
//				System.out.println("문자만 입력해주세요");
//				continue;
//				return onlyString;
//			}
//		}
//	}

	public String rtnString() {
		String rtnStr = "";

		while (true) {
			try {
				rtnStr = sc.nextLine();
				if (rtnStr.trim().length() > 0) {
				}
			} catch (Exception e) {
				System.out.println("문자로 입력해주세요");
			}
			return rtnStr;
		}
	}

	public int rtnInt() {
		while (true) {
			int rtnInt = 0;
			try {
				rtnInt = Integer.parseInt(sc.nextLine());
				return rtnInt;
			} catch (Exception e) {
				System.out.println("숫자가 아닙니다");
			}

		}
	}

	public int change(ArrayList<BookDTO> list) {
		BookDAO dao = new BookDAO();
		int change = 0;
		while (true) {
			System.out.println("금액을 넣어주세요");
			int money = dao.rtnInt();
			System.out.println("입금한 금액은 :" + money + "원\n");
			dao.BookLsit(list);
			System.out.println("도서 번호를 골라 주세요");
			int listNum = dao.rtnInt();
			System.out.println("고르신 책의 가격은 :" + list.get(listNum - 1).getPrice() + "입니다");
			if (money > list.get(listNum - 1).getPrice()) {
				change = money - list.get(listNum - 1).getPrice();
				System.out.println("잔돈은 :" + change + "원 입니다");
				System.out.println("만원 :" + (change / 10000) + ", 오천원 :" + (change % 10000 / 5000) + ", 천원 :"
						+ (change % 5000 / 1000) + ", 오백원 :" + (change % 1000 / 500) + ", 백원 :" + (change % 500 / 100));
			} else {
				System.out.println("돈이 부족합니다");
			}
			return change;
		}

	}

	public int oder(ArrayList<BookDTO> list) {
		BookDAO dao = new BookDAO();
		int change = 0;
		while (true) {
			System.out.println("주문할 책의 번호를 적어주세요\n");
			dao.BookLsit(list);
			int titleNum = dao.rtnInt();
			System.out.println("금액을 넣어주세요");
			int money = dao.rtnInt();

			if (list.size() > titleNum - 1 && titleNum - 1 >= 0) {
				System.out.println("원하는 수량을 입력해주세요");
				int count = dao.rtnInt();
				System.out.println("가격은 :" + (list.get(titleNum - 1).getPrice() * (count)) + "원 입니다");
				if (money >= list.get(titleNum - 1).getPrice() * count) {
					change = money - list.get(titleNum - 1).getPrice();
					System.out.println("잔돈은 :" + change + "원 입니다");
					System.out.println("천원 :" + (change / 1000) + ", 오백원 :" + (change % 1000 / 500) + ", 백원 :"
							+ (change % 500 / 100));

				} else if (money < (list.get(titleNum - 1).getPrice()) * (count)) {
					while (true) {
						System.out.println("돈이 부족합니다 금액을 확인해주세요");
						System.out.println("현재 금액 :" + money + "원");
						System.out.println("금액을 입금해주세요");
						money += dao.rtnInt();
						if(money >= ((list.get(titleNum - 1).getPrice()) * (count))) {
							change = money - list.get(titleNum - 1).getPrice();
							System.out.println("잔돈은 :" + change + "원 입니다");
							System.out.println("천원 :" + (change / 1000) + ", 오백원 :" + (change % 1000 / 500) + ", 백원 :"
									+ (change % 500 / 100));
							break;
						}
					}
				}
			} else {
				System.out.println("책의 번호가 목록에 없습니다");
			}
			return money;
			
		}

	}

}
