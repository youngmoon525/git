package pack06_TestList;

import java.util.ArrayList;

public class BookCRUD {
	public ArrayList<BookDTO> BookCrud(ArrayList<BookDTO> list) {
		BookDTO dto = new BookDTO();
		BookDAO dao = new BookDAO();
		System.out.println("관리자 모드입니다\n");
		System.out.println("1.도서 추가 2.도서 수정 3. 도서 삭제 4. 도서 검색");

		String data = dao.rtnString();
		if (data.equals("1")) {
			System.out.println("도서를 추가 합니다");
			System.out.println("추가할 도서의 제목");
			dto.setTitle(dao.rtnString());
			System.out.println("추가할 도서의 저자");
			dto.setWriter(dao.rtnString());
			System.out.println("추가할 도서의 회사");
			dto.setCompany(dao.rtnString());
			System.out.println("추가할 도서의 금액");
			dto.setPrice(dao.rtnInt());
			list.add(dto);
			dao.BookLsit(list);
		} else if (data.equals("2")) {
			System.out.println("도서를 수정 합니다\n");
			dao.BookLsit(list);
			System.out.println("수정할 도서의 번호를 고르세요");
			int num = dao.rtnInt();
			System.out.println("수정할 도서의 제목을 입력하세요");
			list.get(num - 1).setTitle(dao.rtnString());
			System.out.println("수정할 도서의 저자");
			list.get(num - 1).setWriter(dao.rtnString());
			System.out.println("수정할 도서의 회사");
			list.get(num - 1).setCompany(dao.rtnString());
			System.out.println("수정할 도서의 가격");
			list.get(num - 1).setPrice(dao.rtnInt());
			dao.BookLsit(list);
		} else if (data.equals("3")) {
			System.out.println("선택 도서를 삭제합니다\n");
			dao.BookLsit(list);
			System.out.println("도서의 번호를 입력해주세요");
			list.remove(dao.rtnInt()-1);
			dao.BookLsit(list);
		} else if (data.equals("4")) {
			System.out.println("도서 목록을 검색 합니다 제목을 입력하세요");
			String title = dao.rtnString();
			BookDTO dto1 = null;
			for (int i = 0; i < list.size(); i++) {
				if (title.equals(list.get(i).getTitle())) {
					dto1 = list.get(i);
				}
			}
			if (dto1 != null) {
				System.out.println("책 존재함");
				System.out.println(
						dto1.getTitle() + "\n" + dto1.getWriter() + ".(" + dto1.getCompany() + ")." + dto1.getPrice());
			} else {
				System.out.println("책이 없습니다 주문하세요");
			}
		}

		return list;
	}
}
