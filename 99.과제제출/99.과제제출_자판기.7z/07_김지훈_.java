package exercise;

import java.util.Scanner;
 
public class ex {
 
    public static void main(String[] args) {
        int col = 800;
        int water = 500;
        int vit = 1500;
        
    	Scanner sc = new Scanner(System.in);
        System.out.println("금액을 입력하세요.");
        String money = sc.nextLine();
        int money1 = Integer.parseInt(money);
        

        System.out.println("메뉴를 고르세요");
        System.out.println("1.콜라(800원) 2.생수(500원) 3.비타민워터(1500원) >> ");
        String num = sc.nextLine();
        int num1 = Integer.parseInt(num);
 
        
        if (num1==1 && money1>=col) {
          System.out.println("잔돈 : " + (money1 - col));
        	if(money1>=800) {
        		System.out.println("천원 : " + ((money1 - col)/1000)+ "개, "+"오백원 : "+((money1 - col)%1000/500)+"개, " + "백원 : " + ((money1 - col)%1000%500/100)+ "개");
        	}
        }else if(num1==2 && money1>=water) {
        	System.out.println("잔돈 : " + (money1 - water));
        	if(money1>=500) {
        		System.out.println("천원 : " + ((money1 - water)/1000)+ "개, "+"오백원 : "+((money1 - water)%1000/500)+"개, " + "백원 : " + ((money1 - water)%1000%500/100)+ "개");
        	}
        }else if(num1==3 && money1>=vit) {
        	System.out.println("잔돈 : " + (money1 - vit));
        	if(money1>=1500) {
        		System.out.println("천원 : " + ((money1 - vit)/1000)+ "개, "+"오백원 : "+((money1 - vit)%1000/500)+"개, " + "백원 : " + ((money1 - vit)%1000%500/100)+ "개");
        	}
        }else {
        		System.out.println("돈이 부족합니다.");
        	}
    }
}
