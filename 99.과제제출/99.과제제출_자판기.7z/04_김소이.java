package pack05_etc;

import java.util.Scanner;

public class mini_project {
	public static void main(String[] args) {
		System.out.println("금액을 입력하세요. :");
		Scanner sc = new Scanner(System.in); // 투입금액 입력 받는 스캐너
		String money = sc.nextLine(); // 투입금액을 String 형태의 money로 받음
		System.out.println("메뉴를 고르세요.");
		System.out.println("1.콜라(800원) 2.생수(500원) 3.비타민워터(1500원)");
		String menu = sc.nextLine();// 메뉴를 입력받는 스캐너
		int moneyInt = Integer.parseInt(money); // 투입금액을 int형으로 
		int menuInt = Integer.parseInt(menu); // 입력받은 메뉴를 int 형으로
		int coke = 800; // 콜라
		int water = 500; // 생수
		int vWater = 1500; // 비타민워터
		int exchange = 0; // 잔돈변수 선언
		int cheonWon,obackWon,backWon; // 천원,오백원,백원 변수 선언
		
		if(menuInt==1 && moneyInt>coke) { // 만약에, 고른 메뉴값이 1이고, 투입된 금액이 콜라값보다 크다면
			exchange = moneyInt-coke; // 잔돈은 투입받은금액 - 콜라값
		}else if(menuInt==2 && moneyInt>water){ // 만약에, 고른 메뉴값이 2이고, 투입된 금액이 생수값보다 크다면
			exchange = moneyInt-water; // 잔돈은 투입받은금액 - 생수값
		}else if(menuInt==3 && moneyInt>vWater) { // 만약에, 고른 메뉴값이 3이고, 투입된 금액이 비타민워터값보다 크다면
			exchange = moneyInt-vWater; // 잔돈은 투입받은금액 - 비타민워터값
		}else { // 위의 if문의 조건을 불충족하는 경우 ( 메뉴를 잘못고르거나, 투입금액이 적을 때 )
			exchange = moneyInt; // 잔돈은 투입한 금액을 전부 반환
			System.out.println("금액이 부족합니다.");
		}
		System.out.println("잔돈 : " + exchange +"원"); // 투입한 금액에서 제품금액을 계산 후 남은 잔액
		
		cheonWon = exchange/1000; // 잔돈에서 1000을 나눈 값
		obackWon = exchange%1000/500; // 잔돈에서 1000을 나눈 나머지를 다시 500으로 나눈 값
		backWon = exchange%1000%500/100; // 잔돈에서 1000을 나눈 나머지를 다시 500으로 나누고, 그 나머지를 100으로 나눈 값
		
		System.out.println("천원 : "+cheonWon+" 개"+" 오백원 : "+obackWon+" 개"+" 백원 : "+backWon+" 개");
			
			
			
		}
	}
