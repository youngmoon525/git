package pack01Pract;

import java.util.Scanner;

public class Project {
	public static void main(String[] args) {
		System.out.print("금액을 입력하세요 : ");
		Scanner sc = new Scanner(System.in);
		String inputData = sc.nextLine();
		int coin = Integer.parseInt(inputData);
		System.out.println("메뉴를 고르세요");
		System.out.print("1. 콜라(800원) 2. 생수(500원) 3. 비타민워터(1500원) >> ");
		String menu = sc.nextLine();
		int coins = 0;
		if(menu.equals("1")&&coin>=800) {
			coins = coin-800;
		}else if(menu.equals("2")&&coin>=500) {
			coins = coin-500;
		}else if(menu.equals("3")&&coin>=1500){
			coins = coin-1500;
		}else {
			System.out.println("입력오류");
		}
		System.out.println("잔돈 : " + coins + "원");
		System.out.println("천원 : " + (coins/1000) + "개" + " 오백원 : " +coins%1000/500+ "개" + " 백원 :" + coins%1000%500/100 + " 개");
		
//		int evenSum = 8500;
//		int oddSum = 8500;
//		for(int i=1;i>=100;i++) {
//			if(i%2==0) {
//				continue;
//			}if(i==800) {
//				evenSum--;
//			}
//			oddSum += i;
//		}
//		System.out.println(oddSum);
	}
}
