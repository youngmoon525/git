package pack05_etc;

import java.util.Scanner;

public class projectsample {
	public static void main(String[] args) {
		 Scanner sc = new Scanner(System.in);
	        int money, choice, change = 0; // 넣은 금액, 메뉴 선택, 잔돈
	        int cola = 800; // 콜라
	        int water = 500; // 생수
	        int vitaminWater = 1500; // 비타민워터
	        int oneThousandWon, fiveHundredWon, oneHundredWon = 0; // 천원, 오백원, 백원
	        
	        // 금액 입력
	        System.out.println("금액을 입력하세요.");
	        money = sc.nextInt();
	        
	        // 메뉴 입력
	        System.out.println("메뉴를 고르세요");
	        System.out.print("1.콜라(800원) 2.생수(500원) 3.비타민워터(1500원) >> ");
	        choice = sc.nextInt();
	 
	        // 메뉴 선택 후 잔돈 구하기, 돈이 부족한지 확인
	        if (choice==1 && money>cola) {
	            change = money - cola;
	        } else if (choice==2 && money>water) {
	            change = money - water;
	        } else if (choice==3 && money>vitaminWater) {
	            change = money - vitaminWater;
	        } else {
	            change = money;
	            System.out.println("돈이 부족해요 ㅠㅠ");
	        }
	        
	        System.out.println("잔돈 : " + change + "원");
	        
	        oneThousandWon = change/1000;
	        fiveHundredWon = change%1000/500;
	        oneHundredWon = change%1000%500/100;
	        System.out.print("천원 : " + oneThousandWon + "개, " );
	        System.out.print("오백원 : " + fiveHundredWon + "개, ");
	        System.out.println("백원 : " + oneHundredWon + "개");
	}//main
}//class
