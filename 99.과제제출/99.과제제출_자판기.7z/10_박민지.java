package pack05_etc;

import java.util.Scanner;

public class VM {
	public static void main(String[] args) {
		System.out.println("금액을 입력하세요. : ");
		Scanner sc = new Scanner(System.in);
		String inputData=sc.nextLine();
		int cost=Integer.parseInt(inputData);

		
		System.out.println("메뉴를 고르세요.");
		System.out.println("1.콜라(800원) " + " 2.생수(500원) " + " 3.비타민워터(1500) >>");
		Scanner sc2 = new Scanner(System.in);
		String inputData2=sc.nextLine();
		int menu=Integer.parseInt(inputData2);
		
		if (menu == 1) {
			System.out.println("잔돈: " + (cost - 800));
			System.out.println("천원:" + (cost - 800) / 1000 + "개" + ", 오백원:" + (cost - 800)%1000 / 500 + "개" + ", 백원:"
					+ (cost - 800)%500 / 100 + "개");
		}
		else if (menu == 2) {
			System.out.println("잔돈: " + (cost - 500));
			System.out.println("천원:" + (cost - 500) / 1000 + "개" + ", 오백원:" + (cost - 500)%1000 / 500 + "개" + ", 백원:"
					+ (cost - 500)%500 / 100 + "개");
		}
		else if (menu == 3) {
			System.out.println("잔돈: " + (cost - 1500));
			System.out.println("천원:" + (cost - 1500) / 1000 + "개" + ", 오백원:" + (cost - 1500)%1000 / 500 + "개" + ", 백원:"
					+ (cost - 1500)%500 / 100 + "개");
		}else {
			System.out.println("오류");
		}

		
	}//main
}//class
