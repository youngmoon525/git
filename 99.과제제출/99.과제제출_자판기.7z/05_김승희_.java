package test;

import java.util.Scanner;

public class test {
   public static void main(String[] args) {
	
	   Scanner sc=new Scanner(System.in); 
	   
	     int money1=0;
		 int change=0;
		 int choice=0;
		 int cola=800;
		 int water=500;
		 int vita=1500;
		 int oneThousandWon,fiveHundredWon ,oneHundredWon=0;
		 
		 System.out.println("금액을 입력하세요");
		 money1= sc.nextInt();
				 
		 System.out.println("메뉴를 고르세요");
		 System.out.println("1.콜라(800원) 2.생수(500원) 3.비타민워터(1500원)>>");
		 choice=sc.nextInt();
		 
		 if (choice==1 && money1> cola) {
			 change=money1-cola;
		 }else if (choice==2 && money1>water) {
			 change=money1-water;	 
		 }else if(choice==3 && money1>vita) {
			 change=money1-vita;	 
		 }else {
			 change=money1;
			 System.out.println("돈이 부족합니다");
		 }
             System.out.println("잔돈 : " +change+ "원");
	     
	        oneThousandWon = change/1000;
	        fiveHundredWon=change%1000/500;
	        oneHundredWon=change%1000%500/100;
	        System.out.println("천원:"+ oneThousandWon+ "개,");
	        System.out.println(" 오백원:"+ fiveHundredWon+ "개,");
	        System.out.println("백원:"+ oneHundredWon+ "개");
		 
		 }
		 	   
}






