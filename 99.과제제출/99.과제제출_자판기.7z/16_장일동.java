package pack05_etc;

import java.util.Scanner;

public class Test01 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int pay, menu, coin, aWon, bWon, cWon = 0;
		int cola = 800;
		int water = 500;
		int bWater = 1500;
		
		System.out.print("금액을 입력하세요. : ");
		pay = Integer.parseInt(sc.nextLine());
		
		System.out.println("메뉴를 고르세요. ");
		System.out.print("1.콜라(800원) 2.생수(500원) 3.비타민워터(1500원) >> ");
		menu = Integer.parseInt(sc.nextLine());
		
		if(menu==1) {
			System.out.println("잔돈 : "+(pay-cola)+"원");
			System.out.println("천원 : "+(pay/1000)+"개, 오백원 : "+(pay%1000/500)+"개, 백원 : "+(pay%1000%500/100)+"개");
		}else if (menu==2) {
			System.out.println("잔돈 : "+(pay-water)+"원");
		}else if (menu==3) {
			System.out.println("잔돈 : "+(pay-bWater)+"원");
		}else {
			if (pay<cola || pay<water || pay<bWater) {
				System.out.println("금액이 부족합니다.");
			}
		}

		
		
		
	}
}
