package pack05_etc;

import java.util.Scanner;

public class Ex03_money {

	public static void main(String[] args) {

		String inputData;
		int money;
		int change = 0;

		// 금액을 입력받음. 숫자가 아닐경우 초기화
		Scanner sc = new Scanner(System.in);
		while (true) {
			try {
				System.out.print("금액을 입력하세요 : ");
				inputData = sc.nextLine();
				money = Integer.valueOf(inputData);
				break;
			} catch (Exception e) {
				System.out.println("숫자를 입력해주세요.");
			}
		}
		// 금액이 500 이하가 되거나 4번을 누를 때 까지 반복.
		while (true) {
			System.out.println("메뉴를 고르세요.");
			System.out.print("1. 콜라(800원) 2. 생수(500원) 3. 비타민워터(1500원) 4. 취소 >> ");
			
				String menu = sc.nextLine();
				if (menu.equals("1") && (money >= 800)) { // string의 비교는 ==로 안됨
					change = money - 800;
				} else if (menu.equals("2") && (money >= 500)) {
					change = money - 500;
				} else if (menu.equals("3") && (money >= 1500)) {
					change = money - 1500;
				} else if (menu.equals("4")) {
					System.out.println("취소되었습니다.");
					change = money;
					break;
				} else if (money < 500) {
					// 코인이 500 보다 작을 때
					try {
						change = money;
						System.out.println("코인이 부족합니다.");
						System.out.print("코인을 더 넣으시겠습니까? 1. 예 2.아니오 ");
						String answer = sc.nextLine();
						if (answer.equals("1")) {
							System.out.print("금액을 입력하세요 : ");
							String strcoin = sc.nextLine();
							int coin = Integer.valueOf(strcoin);
							change += coin;
						} else if (answer.equals("2")) {
							System.out.println("취소되었습니다.");
							break;
						} else {
							System.out.println("입력 오류입니다.");
							break;
						}
					} catch (Exception e) {
						System.out.println("숫자를 입력해주세요.");
					}
				} else {
					System.out.println("잘못된 번호 입니다.");
					change = money;
				}
				System.out.println("잔돈 : " + change);
				money = change;

		}
		System.out.println("천원 : " + (change / 1000) + "개" + " 오백원 : " + (change % 1000 / 500) + "개" + " 백원 : "
				+ (change % 1000 % 500 / 100) + "개");
	}

}
