package controlStatement;

import java.util.Scanner;

public class project_JP {
	public static void main(String[] args) {
		Scanner sc1 = new Scanner(System.in);
		System.out.println("금액을 입력하세요. : ");
		String inputData1 = sc1.nextLine();
		System.out.println("메뉴를 고르세요.");
		System.out.println("1. 콜라 (800원) 2.생수 (500원) 3. 비타민워터 (1500원) >>");
		
		Scanner sc2 = new Scanner(System.in);
		String inputData2 = sc2.nextLine();
		
		
		int totalAmount = Integer.parseInt(inputData1);
		int numMenu = Integer.parseInt(inputData2);
		
			if (numMenu == 1) {
				if (numMenu == 1 && totalAmount < 800) {
					System.out.println("돈이 부족합니다.");
				}else {		
				int sum = totalAmount - 800;
				System.out.println("잔돈: " + sum + "원");
					int thousand = sum / 1000;
					int fiveHundred = (sum - (thousand * 1000)) / 500;
					int hundred = (sum - (thousand * 1000) - (fiveHundred *500)) / 100;
				System.out.println("천원: " + thousand + "개,  " + "오백원: " + fiveHundred + "개,  " + "백원: " + hundred + "개");
				}
			}else if (numMenu == 2) {
				if (numMenu == 2 && totalAmount < 500) {
					System.out.println("돈이 부족합니다.");
				}else {	
				int sum = totalAmount - 500;
				System.out.println("잔돈: " + sum + "원");
					int thousand = sum / 1000;
					int fiveHundred = (sum - (thousand * 1000)) / 500;
					int hundred = (sum - (thousand * 1000) - (fiveHundred *500)) / 100;
				System.out.println("천원: " + thousand + "개,  " + "오백원: " + fiveHundred + "개,  " + "백원: " + hundred + "개");		
				}
			}else if (numMenu == 3) {
				if (numMenu == 3 && totalAmount < 1500) {
					System.out.println("돈이 부족합니다.");
				}else {
				int sum = totalAmount - 1500;
				System.out.println("잔돈: " + sum + "원");
					int thousand = sum / 1000;
					int fiveHundred = (sum - (thousand * 1000)) / 500;
					int hundred = (sum - (thousand * 1000) - (fiveHundred *500)) / 100;
				System.out.println("천원: " + thousand + "개,  " + "오백원: " + fiveHundred + "개,  " + "백원: " + hundred + "개");
					}
				}
	}//main
}//class
