package pack05_etc;

import java.math.BigDecimal;
import java.util.Scanner;

public class Mini {
public static void main(String[] args) {
	
	
	System.out.print
	("금액을 입력하세요:");
	Scanner sc =new Scanner(System.in);
	String inputData = sc.nextLine();
	int C = Integer.parseInt(inputData);
	
	System.out.println("메뉴를 고르세요.");
    System.out.println("1.콜라(800) 2.생수 (500원)3.비타민워터(1500원)");
     
      String menuNum = sc.next();
      int drink=Integer.parseInt(menuNum);
           int coke=800;  int water =500 ;  int vitamin =1500;
  
   
     if(drink==1 && C>coke) {
    	 System.out.println("잔돈 : "+(C-coke)+"원");
    	  System.out.print("천원 : "+((C-coke)/1000)+"개");
    	     System.out.print(", 오백원 : "+(((C-coke)%1000)/500)+"개");
    	     System.out.print(", 백원 : "+(((C-coke)%500)/100)+"개");
     }else if(drink==2 && water<=C) {
    	 System.out.println("잔돈 : " +((C-water)+"원"));
    	  System.out.print("천원 : "+((C-water)/1000)+"개");
    	     System.out.print(", 오백원 : "+(((C-water)%1000)/500)+"개");
    	     System.out.print(", 백원 : "+(((C-water)%500)/100)+"개");
     }else if(drink==3&&C>vitamin) {
     	System.out.println("잔돈 : "+(C-vitamin)+"원");
     
     	  System.out.print("천원 : "+((C-vitamin)/1000)+"개");
          System.out.print(", 오백원 : "+(((C-vitamin)%1000)/500)+"개");
          System.out.print(", 백원 : "+(((C-vitamin)%500)/100)+"개");}
     else if(drink>=4 && C>500) {
    	 System.out.println("1~3 번호를 입력해주세요");
     }else {
    	 System.out.println("돈이 부족합니다."); 
     }
   
     
     
     }
    
	}
           

