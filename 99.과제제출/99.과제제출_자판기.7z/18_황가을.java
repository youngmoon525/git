package project;

import java.util.Scanner;

public class P1 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int coke = 800;
		int water = 500;
		int vitamin=1500;
		int change=0;
		
		System.out.println("금액을 입력하세요. :");
		String inputData = sc.nextLine();
		int money =Integer.parseInt(inputData); //금액고르기
		
		System.out.println("메뉴를 고르세요.");
		System.out.println("1.콜라(800원) 2. 생수(500원) 3.비타민워터(1500원)");
		String inputData2 = sc.nextLine();
		int choice =Integer.parseInt(inputData2);
		
		if (choice==1 && money>=coke) {
			change=money-coke;
		}else if(choice==2 && money>=water) {
			change=money-water;
		}else if (choice==3 && money>=vitamin) {
			change=money-vitamin;
		}else if(choice <1 || choice>3) {
			System.out.println("잘못선택하셨습니다.");
		}else {
			change=money;
			System.out.println("돈이 부족합니다.");
		}
		System.out.println("잔돈 : "+change+"원");
		
		System.out.println("천원 : " +(change/1000)+"개");
		System.out.println("오백원 : "+(change%1000/500) +"개");
		System.out.println("백원 : " +(change%1000%500/100)+"개");
		
	}

}
