package pack05_etc;

import java.util.Scanner;

public class Pr {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int money, menu, change = 0;
		int cola = 800;
		int water = 500;
		int vwater = 1500;
		int oTW, fHW, oHW = 0;

		System.out.println("금액을 입력하세요.");
		money = sc.nextInt();

		System.out.println("메뉴를 고르세요.");
		System.out.println("1. 콜라(800원) 2.생수(500원) 3.비타민워터(1500원)");
		menu = sc.nextInt();
		if (menu == 1 && money >= cola) {
			change = money - cola;
		} else if (menu == 2 && money >= water) {
			change = money - water;
		} else if (menu == 3 && money >= vwater) {
			change = money - vwater;
		} else {
			change = money;
			System.out.println("금액이 부족합니다.");
		}
		System.out.println("잔돈은 " + change + "원입니다.");

		oTW = change / 1000;
		fHW = change % 1000 / 500;
		oHW = change % 1000 % 500 / 100;

		System.out.print("천원 : " + oTW + "개, ");
		System.out.print("오백원 : " + fHW + "개, ");
		System.out.println("백원 : " + oHW + "개");

	}// main
}// class
