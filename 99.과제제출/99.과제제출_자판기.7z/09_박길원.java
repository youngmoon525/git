package miniProject;

import java.util.Scanner;

import org.omg.PortableInterceptor.INACTIVE;

public class Ex01_japangi {

	public static void main(String[] args) {
		
		
		System.out.print("금액을 입력하세요 : ");
		Scanner scan = new Scanner(System.in);
		String money = scan.nextLine();
		int A = Integer.parseInt(money);
		System.out.println(A+"원");
		System.out.println("메뉴를 고르세요.");
		
		System.out.println("1.콜라 (800원) 2.생수(500원) 3.비타민워터(1500원) >>");
		
		
		//메뉴 입력
		String namugi = scan.nextLine();
		int B = Integer.parseInt(namugi);
		if(B==1) {
				System.out.println("콜라(800원)");
		}else if(B==2) {
			System.out.println("생수(500원)");
		}else if(B==3) {
			System.out.println("비타민워터(1500원)");
		}else {	
			System.out.println("1~3까지 번호만 입력하십시오");
		}
		
		
		//잔돈 표시
		//거스름돈 개수
		if (B == 1 && A>=800) {
			System.out.println("잔돈 :" + (A - 800) + "원");
			int C = A - 800;
			System.out.print("천원:" + C / 1000 + "개");
			System.out.print(", 오백원:" + (C % 1000) / 500 + "개");
			System.out.println(", 백원:" + (C  % 500 / 100) + "개");
		}else if (B == 2 && A>=500) {
			System.out.println("잔돈 :" + (A - 500) + "원");
			int C = A - 500;
			System.out.print("천원:" + C / 1000 + "개");
			System.out.print(", 오백원:" + (C % 1000) / 500 + "개");
			System.out.println(", 백원:" + (C % 500 / 100) + "개");
		}else if (B == 3 && A>=1500 ) {
			System.out.println("잔돈 :" + (A - 1500) + "원");
			int C = A - 1500;
			System.out.print("천원:" + C / 1000 + "개");
			System.out.print(", 오백원:" + (C % 1000) / 500 + "개");
			System.out.println(", 백원:" + ((C % 500 / 100) + "개"));
		}else {
			System.out.println("금액이 부족합니다.");
			}

			System.out.println("\n안녕히 가세요!");
		
			
		
	}//main

}//Class
