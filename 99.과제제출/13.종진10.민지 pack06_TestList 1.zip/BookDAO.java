package pack06_TestList;

import java.util.ArrayList;
import java.util.Scanner;

public class BookDAO {
	public void display(ArrayList<BookDTO> list) {
		for (int i = 0; i < list.size(); i++) {
			System.out.println(list.get(i).getTitle()+", "+list.get(i).getName()+", "+list.get(i).getPrice()
					+", "+list.get(i).getCompany());
		}
		
	}

	public String rtnString() {
		Scanner sc = new Scanner(System.in);
		String rtnStr = "";
		System.out.println("문자를 입력해주세요");
		while (true) {
			rtnStr = sc.nextLine();
			if (rtnStr.trim().length()>0) {
				return rtnStr;
				
			}
			
		}
	}

	public int rtnInt() {
		Scanner sc = new Scanner(System.in);
		int rtni=0;
		System.out.println("숫자를 입력해주세요");
		while (true) {
			try {
				rtni = Integer.parseInt(sc.nextLine());
				return rtni;
			} catch (Exception e) {
				System.out.println("숫자를 올바르게 입력해주세요");
			}
			
		}
	}
	
	
}
