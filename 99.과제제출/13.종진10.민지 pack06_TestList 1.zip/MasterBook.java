package pack06_TestList;

import java.util.ArrayList;

public class MasterBook {
	public ArrayList<BookDTO> bkdto(ArrayList<BookDTO> list){
		BookDAO dao = new BookDAO();
		dao.display(list);
			
		System.out.println("관리자모드");
		System.out.println("1. 도서추가 2.도서수정 3.도서삭제 4.도서검색");
		String inputData = dao.rtnString();
		if (inputData.equals("1")) {
			System.out.println("도서를 추가합니다");
			BookDTO dto = new BookDTO();
			System.out.println("도서의 제목을 입력해주세요");
			dto.setTitle(dao.rtnString());
			System.out.println("도서의 저자를 입력해주세요");
			dto.setName(dao.rtnString());
			System.out.println("도서의 가격을 입력해주세요");
			dto.setPrice(dao.rtnInt());
			System.out.println("도서의 출판사를 입력해주세요");
			dto.setCompany(dao.rtnString());
			list.add(dto);
			dao.display(list);
		}else if (inputData.equals("2")) {
			System.out.println("도서를 수정합니다");
			System.out.println("수정할 도서의 번호를 선택하세요");
			System.out.println("도서의 제목을 입력해주세요");
			list.get(dao.rtnInt()-1).setTitle(dao.rtnString());
			System.out.println("도서의 작가를 입력해주세요");
			list.get(dao.rtnInt()-1).setName(dao.rtnString());
			System.out.println("도서의 출판사를 입력해주세요");
			list.get(dao.rtnInt()-1).setCompany(dao.rtnString());
			System.out.println("도서의 가격을 입력해주세요");
			list.get(dao.rtnInt()-1).setPrice(dao.rtnInt());
			dao.display(list);
		}else if (inputData.equals("3")) {
			System.out.println("도서를 삭제합니다");
			System.out.println("삭제할 번호를 선택하세요");
			list.remove(dao.rtnInt()-1);
			dao.display(list);
		}

		
		
		return list;
		
	}
}
