package pack06_TestList;

import java.util.ArrayList;


public class BookMain {
	public static void main(String[] args) {
		System.out.println("도서 관리 프로그램이 시작됩니다.");
		ArrayList<BookDTO> list = new ArrayList<BookDTO>();
		list.add(new BookDTO("백만장자의 눈", "로알드 달", "담푸스", 11000));
		list.add(new BookDTO("달러구트 꿈백화점", "이미예", "팩토리나인", 13800));
		list.add(new BookDTO("사서함 110호의 우편물", "이도우", "시공사", 13000));
		list.add(new BookDTO("완전한 행복", "정유정", "은행나무", 15800));
		BookDAO dao = new BookDAO();
		while (true) {
			System.out.println("1.관리자모드 2.사용자모드 ▶그 외 키를 누르시면 종료됩니다.");
			String inputData = dao.rtnString();
			if (inputData.equals("1")) {
				MasterBook mb = new MasterBook();
				list=mb.bkdto(list);
			}else if (inputData.equals("2")) {
				UserBook ub = new UserBook();
				ub.usBook(list);
			}else if (inputData.equals("x")) {
				System.out.println("도서 관리 프로그램을 종료합니다");
			}
		}
	}
}
