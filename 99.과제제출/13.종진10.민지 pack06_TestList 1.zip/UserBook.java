package pack06_TestList;

import java.util.ArrayList;

public class UserBook {
	int coin;

	public void usBook(ArrayList<BookDTO> list) {
		BookDAO dao = new BookDAO();
		System.out.println("사용자 모드");
		dao.display(list);
		System.out.println("금액을 입력해주세요");
		coin = dao.rtnInt();

		System.out.println("도서 목록을 조회해주세요");
		dao.display(list);

		System.out.println("도서를 선택해주세요");
		int num = dao.rtnInt() - 1;
		if (coin >= list.get(num).getPrice()) {
			coin = coin - list.get(dao.rtnInt() - 1).getPrice();
		}else {
			System.out.println("잔돈을 배출합니다");
		}System.out.println("잔돈"+coin);
	}

}
