package pack06_TestList;

import java.util.ArrayList;

public class MasterBook {

	public ArrayList<BookDTO> mstbook(ArrayList<BookDTO> list) {

		BookDAO dao = new BookDAO();
		System.out.println("관리자 모드");
		dao.display(list);
		
		System.out.println("\n1. 도서 추가 2. 도서 수정 3. 도서 삭제 4. 도서 검색");
		String inputData = dao.rtnString();
		
		if(inputData.equals("1")) {
			System.out.println("도서 추가 하겠습니다.");
			BookDTO dto = new BookDTO();
			System.out.println("도서 제목을 입력해주세요.");
			dto.setTitle(dao.rtnString());
			System.out.println("도서 저자를 입력해주세요.");
			dto.setWriter(dao.rtnString());
			System.out.println("도서 출판사를 입력해주세요.");
			dto.setCompany(dao.rtnString());
			System.out.println("도서 가격을 입력해주세요.");
			dto.setPrice(dao.rtnInt());
			list.add(dto);
			dao.display(list);
			
		}else if(inputData.equals("2")){
			System.out.println("도서 수정을 하겠습니다.");
			dao.display(list);
			
			while(true) {
			System.out.println("수정할 도서의 번호를 선택해주세요.");
			int aa = dao.rtnInt()-1;
			if(aa>=0&&aa<=list.size()-1) {
			System.out.println("도서의 제목을 입력해주세요");
			list.get(aa).setTitle(dao.rtnString());
			System.out.println("도서의 저자를 입력해주세요");
			list.get(aa).setWriter(dao.rtnString());
			System.out.println("도서의 출판사를 입력해주세요");
			list.get(aa).setCompany(dao.rtnString());
			System.out.println("도서의 가격을 입력해주세요");
			list.get(aa).setPrice(dao.rtnInt());
			dao.display(list);
			break;
			
			} else {
				System.out.println("\n수정할 도서의 번호를 다시입력해 주세요");
				
				}
			}
			
		} else if(inputData.equals("3")) {
			System.out.println("도서 삭제를 하겠습니다.");
			dao.display(list);
			while(true) {
				System.out.println("삭제할 번호를 선택하세요.");
				int aaa = dao.rtnInt()-1;
			if(aaa>=0&&aaa<=list.size()-1) {
			list.remove(aaa);
				dao.display(list);
				break;
			}else {
				System.out.println("삭제할 번호를 다시 입력해주세요.");
				}
			}
			
		}else if(inputData.equals("4")) {
			System.out.println("도서 검색를 하겠습니다.");
			dao.display(list);
			String title = dao.rtnString();
			BookDTO dto = null;
				for (int i = 0; i < list.size(); i++) {
					if(title.equals(list.get(i).getTitle())) {
						dto=list.get(i);
					}
				}	
					if(dto!= null) {
						System.out.println("책있음");
						System.out.println(dto.getTitle() + ", " + dto.getWriter() + ", " + dto.getCompany() + ", " + dto.getPrice());
					}else {
						System.out.println("책없음");
				}
		
	}
		return list;
	}
}