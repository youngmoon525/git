package pack06_TestList;

import java.util.ArrayList;

public class BuyMode {
	public ArrayList<BookDTO> buyMode(ArrayList<BookDTO>list)throws InterruptedException {
		int coin;
		System.out.println("금액을 입력해주세요.");
		BookStoreDAO dao = new BookStoreDAO();
		dao.display(list);
		coin = dao.rtnInt(); //-------->금액 입력완료
		while (true) {
			System.out.println("구매하시려는 책 번호를 선택해주세요.");
			int num = dao.rtnInt();
			System.out.println(list.get(num-1).getBookName()+ "를(을) 선택하셨습니다.");
			if (num <= list.size()+1 && num >=0) {
				System.out.println("구매하시려는 책의 수량을 입력해주세요.");
				int userAmount = dao.rtnInt();
				for (int i = 0; i < list.size(); i++) {
					if (num == i + 1 && coin >= list.get(num - 1).getPrice() * userAmount
						&& userAmount <= list.get(i).getAmount() && userAmount >0) {
						coin = coin - list.get(num - 1).getPrice() * userAmount;
						BookDTO dto = new BookDTO();
						list.get(i).setAmount(list.get(i).getAmount() - userAmount);
						System.out.println("선택하신 " + list.get(num - 1).getBookName() + "가 구매되었습니다.");
						dao.display(list);
						break;
					} else if (num == i + 1 && coin <= list.get(num - 1).getPrice() * userAmount
						&& userAmount <= list.get(i).getAmount()) {
						System.out.println("돈이 부족합니다.");
						break;
					} else if (num == i + 1 && coin >= list.get(num - 1).getPrice() * userAmount
						&& userAmount > list.get(i).getAmount()) {
						System.out.println("구매하시려는 책의 수량이 서점이 보유한 수량보다 많습니다.");
					} else if (num == i + 1 && userAmount<=0) {
						System.out.println("구매하시려는 책의 수량을 정확히 입력해주세요.");
					}
							
				}
				System.out.println("잔돈을 받으세요.");
				Thread.sleep(500);
				System.out.println("잔돈 : "+coin);
				Thread.sleep(1000);
				System.out.println("구매하기를 끝내시려면 exit를 계속하시려면 아무키나 입력해주세요.");
				String inputData = dao.rtnString();
				if (inputData.equalsIgnoreCase("exit")){
						System.out.println("10초 뒤 첫 화면으로 돌아갑니다.");
						Thread.sleep(1000);
						break;
					} 
			}else {
				System.out.println("입력하신 번호에 해당하는 도서가 없습니다.");
			}
			
		}
		return list;
	}
}
