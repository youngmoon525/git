package pack06_TestList;

import java.util.ArrayList;

public class BookStoreMain {

	public static void main(String[] args)throws InterruptedException {
//		1.관리자 모드 (CRUD) --->MasterStore 클래스에서 실행
//		-1.도서 추가  --->Scanner String메소드 사용
//		-2.도서 수정
//		-3.도서 삭제
//		-4.도서 검색 (모든 기능이 완료 되면 추가 할 것 , 도서의 제목을 입력하면 도서의 
//				제목 , 저자 , 출판사 , 가격 이 출력 됨) for if
		//ArrayList for문으로 돌리고 if문으로 사용자가 선택한 도서 검색
//		BookDTO -->String name,String writer,String publisher,int price를 private로 만들고
		//using field, getter&setter 만들기
//	2.사용자 모드 ---->BookStoreDAO에서 메소드로 만들고 Main에서 실행
//		-0.금액 입력 --->Scanner int 메소드 사용
//		-1.도서 목록 조회
//		-2.도서 주문
//			     (도서를 선택 후 주문함 , 추후 도서를 몇권 주문할건지 선택 가능)
//		-3.잔돈 배출
		
		System.out.println("가을이네 책방에 오신걸 환영합니다♥");
		
		ArrayList<BookDTO> list = new ArrayList<BookDTO>();
		list.add(new BookDTO("혼자 공부하는 자바", "신용권", "한빛미디어", 30000, 5));
		list.add(new BookDTO("생각이 너무 많은 서른 살에게", "김은주", "메이븐", 16000, 2));
		list.add(new BookDTO("미움받을 용기", "기시미 이치로, 고가 후미타케", "인플루엔셜", 14900, 3));
		
		BookStoreDAO dao = new BookStoreDAO();
		
		while (true) {
			System.out.println("원하시는 번호를 입력해주세요.");
			System.out.println("1.구매하기 2.관리자 모드 3.종료");
			int inputData = dao.rtnInt();
			if (inputData==1) {
				//buymode 구매하기 옵션 메소드
				BuyMode bm = new BuyMode();
				bm.buyMode(list);
				
			} else if (inputData==2) {
				//Mater 메소드
				MasterBookStore ms = new MasterBookStore();
				ms.mstStore(list);
				
			} else if (inputData==3){
				System.out.println("감사합니다. 다음에 또 오세요.");
				break;
			}
		}
	}

}
