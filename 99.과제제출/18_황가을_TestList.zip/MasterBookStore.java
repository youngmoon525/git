package pack06_TestList;

import java.util.ArrayList;

public class MasterBookStore {
	public ArrayList<BookDTO> mstStore(ArrayList<BookDTO> list) throws InterruptedException {
		BookStoreDAO dao = new BookStoreDAO();
		int userNum;
		String inputData;
		while (true) {
			try {
				System.out.println("관리자 모드입니다.\n원하는 번호를 입력해주세요.");
				System.out.println("1.도서 추가 2.도서 수정 3.도서 삭제 4.도서 검색 5.첫 화면으로 돌아가기");

				inputData = dao.rtnString();
				if (inputData.equals("1")) {
					System.out.println("도서를 추가합니다.");
					while (true) {
						System.out.println("1.계속하기 2.이전 화면으로 돌아가기");
						BookDTO dto = new BookDTO();
						inputData = dao.rtnString();
						if (inputData.equals("1")) {
							System.out.println("도서의 이름을 입력해주세요.");
							dto.setBookName(dao.rtnString());
							System.out.println("도서의 저자를 입력해주세요.");
							dto.setWriter(dao.rtnString());
							System.out.println("도서의 출판사를 입력해주세요.");
							dto.setPublisher(dao.rtnString());
							System.out.println("도서의 가격을 입력해주세요.");
							dto.setPrice(dao.rtnInt());
							System.out.println("도서의 수량을 입력해주세요.");
							dto.setAmount(dao.rtnInt());
							list.add(dto);
							dao.display(list);
						} else if (inputData.equals("2")) {
							System.out.println("5초 후 이전화면으로 돌아갑니다.");
							Thread.sleep(500);
							break;
						} else {
							System.out.println("잘못 입력하셨습니다.");
						}
					}
				} else if (inputData.equals("2")) {
					System.out.println("도서 수정모드입니다.");
					while (true) {
						System.out.println("1.계속하기 2.이전 화면으로 돌아가기");
						inputData = dao.rtnString();
						if (inputData.equals("1")) {
							System.out.println("수정 할 도서의 번호를 입력해주세요.");
							dao.display(list);
							userNum = dao.rtnInt();
							if (userNum<=list.size() && userNum>=0) {
								System.out.println("도서의 제목을 입력해주세요.");
								list.get(userNum - 1).setBookName(dao.rtnString());
								System.out.println("도서의 저자를 입력해주세요.");
								list.get(userNum - 1).setWriter(dao.rtnString());
								System.out.println("도서의 출판사를 입력해주세요.");
								list.get(userNum - 1).setPublisher(dao.rtnString());
								System.out.println("도서의 가격을 입력해주세요.");
								list.get(userNum - 1).setPrice(dao.rtnInt());
								System.out.println("도서의 수량을 입력해주세요.");
								list.get(userNum - 1).setAmount(dao.rtnInt());
								dao.display(list);
								System.out.println("도서 수정이 완료됐습니다.");
							} else {
								System.out.println("입력하신 번호에 등록된 도서가 없습니다.");
							}
						} else if (inputData.equals("2")) {
							System.out.println("5초 후 이전화면으로 돌아갑니다.");
							Thread.sleep(500);
							break;
						} else {
							System.out.println("잘못 입력하셨습니다.");
						}
					}
				} else if (inputData.equals("3")) {
					System.out.println("도서 삭제모드입니다.");
					while (true) {
						System.out.println("1.계속하기 2.이전 화면으로 돌아가기");
						inputData = dao.rtnString();
						if (inputData.equals("1")) {
							System.out.println("삭제할 도서의 번호를 입력하세요.");
							dao.display(list);
							userNum = dao.rtnInt();
							if (userNum>list.size() && userNum<0) {
								System.out.println("입력하신 번호에 등록된 도서가 없습니다.");
							} else {
								list.remove(userNum-1);
								dao.display(list);
								System.out.println("삭제가 완료됐습니다.");
							}
						} else if (inputData.equals("2")) {
							System.out.println("5초 후 이전화면으로 돌아갑니다.");
							Thread.sleep(500);
							break;
						} else {
							System.out.println("잘못 입력하셨습니다.");
						}
					}
				} else if (inputData.equals("4")) {
					System.out.println("도서를 검색합니다.");
					while (true) {
						System.out.println("검색할 유형을 선택해주세요.");
						System.out.println("1.도서 이름으로 검색 2.등록된 도서 번호로 검색 3.이전 화면으로 돌아가기");
						userNum = dao.rtnInt();
						if (userNum == 1) {
							System.out.println("검색할 도서의 이름을 입력해주세요.");
							inputData = dao.rtnString();
							for (int i = 0; i < list.size(); i++) {
								if (inputData.equals(list.get(i).getBookName())) {
									System.out.println(
											(i + 1) + "." + list.get(i).getBookName() + "/" + list.get(i).getWriter()
													+ "/" + list.get(i).getPublisher() + "/" + list.get(i).getPrice()
													+"/ 수량 :"+list.get(i).getAmount()+"권");
									break;
								} else if (i == list.size() - 1) {
									System.out.println("입력하신 책은 등록된 책이 아닙니다.");
								}
							}
						} else if (userNum == 2) {
							System.out.println("검색할 도서의 번호를 입력해주세요.");
							System.out.println("등록된 도서량 : " + list.size());
							userNum = dao.rtnInt();
							for (int i = 0; i < list.size(); i++) {
								if (userNum == i + 1) {
									System.out.println(
											(i + 1) + "." + list.get(i).getBookName() + "/" + list.get(i).getWriter()
													+ "/" + list.get(i).getPublisher() + "/" + list.get(i).getPrice()
													+"/ 수량 :"+list.get(i).getAmount()+"권");
									break;
								} else if (i == list.size() - 1) {
									System.out.println("입력하신 번호에 해당하는 도서가 없습니다.");
								}
							}
						} else if (userNum == 3) {
							System.out.println("5초 후 이전화면으로 돌아갑니다.");
							Thread.sleep(500);
							break;
						} else {
							System.out.println("잘못 입력하셨습니다.");
						}

					}
				} else if (inputData.equals("5")) {
					System.out.println("관리자 모드를 종료합니다. \n10초 후 첫 화면으로 돌아갑니다.");
					Thread.sleep(1000);
					break;
				}
			} catch (Exception e) {
				System.out.println("잘못입력하셨습니다.");
			}
		}
		return list;
	}
}
