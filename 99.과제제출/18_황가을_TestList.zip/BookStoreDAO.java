package pack06_TestList;

import java.util.ArrayList;
import java.util.Scanner;

public class BookStoreDAO {
	public int rtnInt() { //스캐너 정수값
		Scanner sc = new Scanner(System.in);
		int rtnI;
		while (true) {
			try {
				rtnI= Integer.parseInt(sc.nextLine());
				return rtnI;
			} catch (Exception e) {
				System.out.println("숫자값만 입력해주세요.");
			}
		}
	}
	
	public String rtnString() { // 스캐너 문자값
		Scanner sc= new Scanner(System.in);
		String rtnStr;
		while (true) {
			try {
				
				rtnStr = sc.nextLine();
				if (rtnStr.trim().length()>0) {
					return rtnStr;
				}
			} catch (Exception e) {
				System.out.println("문자만 입력해주세요.");
			}
		}
	}
	
	public void display(ArrayList<BookDTO> list) { //책목록
		for (int i = 0; i < list.size(); i++) {
			System.out.println((i+1)+"."+list.get(i).getBookName()+"/"+list.get(i).getWriter()+
					"/"+list.get(i).getPublisher()+"/"+list.get(i).getPrice()+"/ 수량 : "+list.get(i).getAmount()+"권");
		}
	}
}
