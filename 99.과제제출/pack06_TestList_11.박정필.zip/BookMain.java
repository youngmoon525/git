package pack06_TestList;

import java.util.ArrayList;


public class BookMain {
	public static void main(String[] args) {
		System.out.println("도서 관리 프로그램 시작됨");
		
		ArrayList<BookDTO> list = new ArrayList<BookDTO>();
		list.add(new BookDTO("달러구트 꿈 백화점 2", "이미예", "팩토리나인", 13800));
		list.add(new BookDTO("밝은 밤", "최은영", "문학동네", 14500));
		list.add(new BookDTO("완전한 행복", "정유정", "은행나무", 15800));
		
		BookDAO dao = new BookDAO();
		
		while (true) {
			System.out.println("1.관리자 모드  2.사용자 모드 ▶ 그 외 q키를 누르면 종료 됩니다.");
			String inputData = dao.rtnString();
			
			if (inputData.equals("1")) {
				MasterBook mb = new MasterBook();
				list = mb.mstBook(list);
			}else if (inputData.equals("2")) {
				UserBook ub = new UserBook();
				ub.usBook(list);
			}else if (inputData.equals("q")) {
				System.out.println("도서 관리 프로그램을 종료합니다.");
				break;
			}
		}//while
		
	}//main
}//class


