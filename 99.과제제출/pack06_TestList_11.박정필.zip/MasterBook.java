package pack06_TestList;

import java.util.ArrayList;

public class MasterBook {

	public ArrayList<BookDTO> mstBook(ArrayList<BookDTO> list) {
		
		BookDAO dao = new BookDAO();
		//dao.display(list);
		String inputData ;
		
	//	if (inputData.equals("1")) {
			System.out.println("관리자 모드");
			System.out.println("1. 도서 추가 2. 도서 수정 3. 도서 삭제 4. 도서 검색 ");
		
			inputData = dao.rtnString();
			if (inputData.equals("1")) {
				System.out.println("도서 추가 로직 시작");
				BookDTO dto = new BookDTO();
				
				System.out.println("도서의 이름을 입력해주세요.");
				dto.setName(dao.rtnString());
				System.out.println("도서의 저자를 입력해주세요.");
				dto.setAuthor(dao.rtnString());
				System.out.println("도서의 출판사를 입력해주세요.");
				dto.setAuthor(dao.rtnString());
				System.out.println("도서의 가격을 입력해주세요.");
				dto.setPublisher(dao.rtnString());
				list.add(dto);
				dao.display(list);
			}else if (inputData.equals("2")) {
				System.out.println("도서 수정 로직 시작");
				System.out.println("수정할 도서 목록 번호를 선택하세요.");
				dao.display(list);
				
				int listNum = dao.rtnInt();
				
				System.out.println("도서의 이름을 적어주세요.");
				list.get(listNum-1).setName(dao.rtnString());
				System.out.println("도서의 저자를 입력해주세요.");
				list.get(listNum-1).setAuthor(dao.rtnString());
				System.out.println("도서의 출판사를 입력해주세요.");
				list.get(listNum-1).setPublisher(dao.rtnString());
				System.out.println("도서의 가격을 입력해주세요.");
				list.get(listNum-1).setPrice(dao.rtnInt());
				dao.display(list);
			}else if (inputData.equals("3")) {
				System.out.println("도서 삭제 로직 시작");
				dao.display(list);
				System.out.println("삭제할 도서 목록 번호를 선택하세요.");
				
				list.remove(dao.rtnInt()-1);
				dao.display(list);
				
			}
			/*else if (inputData.equals("4")) {
				System.out.println("도서 검색 로직 시작");
				
				System.out.println("도서 제목을 입력해주세요.");
				String searchStr = dao.rtnString();
				
				for (int i = 0; i < list.size(); i++) {
										
					if (searchStr.equals(list.get(i).getName())) {
						
					}
					
				}
				
				
				
			}*/
		//}//if
				
		return list;
	}//mstBook

}//class
