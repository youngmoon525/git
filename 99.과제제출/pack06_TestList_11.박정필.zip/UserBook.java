package pack06_TestList;

import java.util.ArrayList;

public class UserBook {
	int coin;
	public void usBook(ArrayList<BookDTO> list) {
		BookDAO dao = new BookDAO();
		System.out.println("사용자 모드");
		System.out.println("금액을 입력해주세요.");
		coin = dao.rtnInt();
		
		System.out.println("도서를 선택해 주세요.");
		dao.display(list);
		int num = dao.rtnInt() -1;
		if (coin >= list.get(num).getPrice()) {
			coin = coin - list.get(num).getPrice();
		}else {
			System.out.println("돈을 다시 입력하세요 잔돈을 배출 합니다.");
		}
		System.out.println(("잔돈 " + coin ));
	}// list

}//class
