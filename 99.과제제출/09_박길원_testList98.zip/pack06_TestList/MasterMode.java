package pack06_TestList;

import java.util.ArrayList;
import java.util.Scanner;

public class MasterMode {
	BookDAO dao = new BookDAO();
	public ArrayList<BookDTO> ms(ArrayList<BookDTO>list){
		Scanner sc = new Scanner(System.in);
		System.out.println("관리자 모드입니다. \n메뉴를 선택해주세요.\n"
				+ "1.도서 추가, 2.도서 제거, 3도서 수정, 4.도서 검색");
		int choice =  dao.rtnInt();
		while(choice<1||choice>4) {
			System.out.println("관리자 모드입니다. \n메뉴를 선택해주세요.\n"
					+ "1.도서 추가, 2.도서 제거, 3도서 수정, 4.도서 검색");
			choice =  dao.rtnInt();
		}
		if(choice==1) {
			dao.addbook(list);
		}
		else if(choice==2) {
			dao.removebook(list);
		}
		else if(choice==3) {
			dao.resetbook(list);
		}
		else if(choice==4) {
			dao.findbook(list);
		}
		return list;
	}
}
