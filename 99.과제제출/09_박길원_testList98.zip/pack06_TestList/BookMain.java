package pack06_TestList;

import java.util.ArrayList;
import java.util.Scanner;

import pack04_japangi.userMode;


public class BookMain {
/*1.관리자 모드
 -1.도서 추가
 -2.도서 수정
 -3.도서 삭제
 -4.도서 검색(for if 사용)(모든 기능이 완료 되면 추가 할 것 , 도서의 제목을 입력하면 도서의 
			제목 , 저자 , 출판사 , 가격 이 출력 됨)
 
 2.사용자 모드
 -1.금액입력
 -2.도서목록 조회
 -3.도서주문 (도서를 선택 후 주문함 , 추후 도서를 몇권 주문할건지 선택 가능)
 -4.잔돈 배출*/
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		MasterMode ms = new MasterMode();
		UserMode us = new UserMode();
	BookDTO dto = new BookDTO();
	BookDAO dao = new BookDAO();
	ArrayList<BookDTO> list = new ArrayList<BookDTO>();
	list.add(new BookDTO(1, "세상의 모든 법칙","이재명","이른아침", 16000));
	list.add(new BookDTO(2, "통섭의 식탁","최재천","움직이는서재", 15000));
	list.add(new BookDTO(3, "[흄]의 인간 오성에 관한 탐구","A.베일리, D.오브리언","이른아침", 21000));
	
	boolean cont = true;
	while (cont) {
		System.out.println("숫자를 입력해주세요. 관리자 모드 : 1, 그 외는 사용자모드");
		int inputNum = dao.rtnInt();//시스템 가동
		if (inputNum == 1) {
			list=ms.ms(list);//관리자모드
		}
		else {
			us.userMode(list);// 사용자 모드
		}
		cont = dao.cont();//시스템 재가동 메소드
	}
	
	
	
	
	
	
	}
}
