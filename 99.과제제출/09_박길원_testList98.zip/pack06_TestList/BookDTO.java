package pack06_TestList;

public class BookDTO {
 int number;
 String title;
 int price;
 String author;
 String company;
 public BookDTO() {}
 
public BookDTO(int number, String title, String author, String company, int price) {
	this.number = number;
	this.title = title;
	this.author = author;
	this.company = company;
	this.price = price;
}
 
}
