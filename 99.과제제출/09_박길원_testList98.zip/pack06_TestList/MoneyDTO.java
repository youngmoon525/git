package pack06_TestList;

public class MoneyDTO {
int money;
public MoneyDTO() {}

public MoneyDTO(int money) {
 this.money=money;}
}
