package pack06_TestList;

import java.util.ArrayList;
import java.util.Scanner;

import pack04_japangi.DrinkDTO;

public class BookDAO {
	MoneyDTO mto = new MoneyDTO();
	BookDTO dto = new BookDTO();
	Scanner sc = new Scanner(System.in);
	//관리자 모드
	/*1.관리자 모드
	 -1.도서 추가v
	 -2.도서 수정v
	 -3.도서 삭제v
	 -4.도서 검색(for if 사용)(모든 기능이 완료 되면 추가 할 것 , 도서의 제목을 입력하면 도서의 
				제목 , 저자 , 출판사 , 가격 이 출력 됨)
	 
	 2.사용자 모드
	 -1.금액입력
	 -2.도서목록 조회
	 -3.도서주문 (도서를 선택 후 주문함 , 추후 도서를 몇권 주문할건지 선택 가능)
	 -4.잔돈 배출*/
	public void bookDisplay(ArrayList<BookDTO> list) {
		// 인스턴스화 해서 가지고 왔기 때문에 여기서 굳이 또 인스턴스화 안해도 해당 클래스의 메소드 사용 가능
		for (int i = 0; i < list.size(); i++) {
			System.out.println(list.get(i).number+". "+list.get(i).title+", "
		+list.get(i).author+", "+list.get(i).company+", "+list.get(i).price+"원");
		}//bookDisplay(list)

	}

	//관리자 모드에 필요한 메소드
	public ArrayList<BookDTO> addbook(ArrayList<BookDTO> list) {//메뉴 추가
		System.out.println("추가하려는 도서명을 입력하세요");
		String name = rtnString();
		System.out.println("추가하려는 도서의 저자를 입력하세요.");
		String author = rtnString();
		System.out.println("추가하려는 도서의 출판사를 입력하세요.");
		String company = rtnString();;
		System.out.println("추가하려는 도서의 가격을 입력하세요.");
		int price = rtnInt();
		list.add(new BookDTO(list.size()+1, name, author, company,price));
		bookDisplay(list);
		return list;
		//
	}

	public ArrayList<BookDTO> removebook(ArrayList<BookDTO> list){//메뉴 제거
		bookDisplay(list);
		Scanner sc = new Scanner(System.in);
		System.out.println("삭제하려는 도서의 번호를 눌러주세요.");
		int num = rtnInt();
		list.remove(num-1);
		bookDisplay(list);
		return list;
	}
	
	public ArrayList<BookDTO> resetbook(ArrayList<BookDTO> list){//메뉴 수정
			bookDisplay(list);
			Scanner sc = new Scanner(System.in);
			System.out.println("수정하려는 도서의 번호를 눌러주세요.");
			int number = rtnInt();
			System.out.println("도서명을 입력하세요");
			String name = rtnString();
			System.out.println("저자명을 입력하세요.");
			String author = rtnString();
			System.out.println("출판사를 입력하세요.");
			String company = rtnString();
			System.out.println("가격을 입력하세요.");
			int price = rtnInt();
			list.add(number-1, new BookDTO(number, name,author, company , price));
			list.remove(number);
			bookDisplay(list);
		return list;
	}
	
	public void findbook(ArrayList<BookDTO> list){
		System.out.println("정보가 필요한 책의 제목을 입력해주세요.");
		String name = rtnString();
		for (int i = 0; i < list.size(); i++) {
			if(list.get(i).title.equals(name)) {
				System.out.println(list.get(i).number+". "+list.get(i).title+", "
						+list.get(i).author+", "+list.get(i).company+", "+list.get(i).price+"원");
			}
		}
	
	}
	//============관리자 모드에 필요한 기능 끝=================
	
	//============사용자모드에 필요한 기능===================
	
	public int inputCoin(int coin) {// 투입금액 표시와
		System.out.println("금액을 넣어주세요");
		while(true) {
			try {				
			int Money = rtnInt();
			if (Money< 0) {	
			throw new Exception();
		} 
			else if (Money >= 0) {
			System.out.println(Money + "원");
			
			return Money;
		}
			}catch (Exception e) {
				System.out.println("돈을 제대로 넣어주세요^^");
				System.out.println("금액투입");
			}
		}
		
	}

	public int menu(ArrayList<BookDTO> list) {// 메뉴 입력
		bookDisplay(list);
		System.out.println("메뉴를 골라주세요");
		while(true) {
		try{int menu = rtnInt()-1;
		System.out.println("이 책은 "+list.get(menu).price+"입니다.");
		System.out.println("몇권 주문하시겠습니까?");
		int amount = rtnInt();
		int price = list.get(menu).price*amount;
		System.out.println("지불하셔야할 가격은 총 "+price+" 입니다.");
		return price;
		}catch (Exception e) {
			System.out.println("1~"+list.size()+"까지의 수를 입력해주세요");
			}
		}
		
	}
	public int addMoney(int A) {//금액 추가
		System.out.println("금액이 "+(-A) +"만큼 부족합니다. 돈을 더 넣어주세요");
		int add = rtnInt();
		A += add;
		return A;
	}
	
	public void change(int A ) { // 잔돈, 거스름돈 개수 표시
		System.out.println("내신 금액은 " + A+"입니다.");
		if (A >= 0) {
			System.out.print("오만원 : "+A/50000+"개");
			System.out.print(", 만원 : "+(A%50000)/10000+"개");
			System.out.print(", 오천원 : "+(A%10000)/5000+"개");
			System.out.print(", 천원: " + (A%5000)/1000 + "개");
			System.out.print(", 오백원: " + (A % 1000) / 500 + "개");
			System.out.println(", 백원: " + (A % 500 / 100) + "개");
		}
	}
	
	//=================사용자모드에 필요한 기능 끝===============
	
	//=================공통으로 필요한 기능 ===================
	public boolean cont() {//시스템 재가동
		System.out.println("시스템을 다시 시작하려면 1번, 종료하려면 다른 키를 눌러주세요");
		try{int choice = rtnInt();
		if(choice==1) {return true;}
		else {throw new Exception();}
		}catch (Exception e) {
			System.out.println("프로그램을 종료합니다.");
			return false;
		}
		
	}
	
	public int rtnInt() {//정수만 입력받는 메소드
		Scanner sc = new Scanner(System.in);
		int num=0;
		while(true) {
		try{num = Integer.parseInt(sc.nextLine());
		if(num<0) {
			throw new Exception();
		}
		return num;
		}catch (Exception e) {
			System.out.println("숫자만 입력해주세요.");
		}
		}
	}
	public String rtnString() {//문자 입력받는 메소드
		Scanner sc = new Scanner(System.in);
		String str=null;
		while(true) {
		str=sc.nextLine();
		if(str.length()>0) {
		break;	
		}
		System.out.println("적어도 한글자 이상 입력해주세요.");
		}
		return str;
	}
	//=================공통으로 필요한 기능 끝 ===============

}
