package pack06_TestList;

import java.util.ArrayList;


public class UserMode {

	pack06_TestList.MoneyDTO mto = new MoneyDTO();
	BookDAO dao= new BookDAO();
	
	public void userMode(ArrayList<BookDTO> list){
		System.out.println("사용자 모드");

		// 금액투입
		mto.money = dao.inputCoin(mto.money);

		// 메뉴 선택
		mto.money = mto.money - dao.menu(list);
		while(mto.money < 0) {
			mto.money = dao.addMoney(mto.money);
		}
		System.out.println("계산 되었습니다. 잔돈은 : "+ mto.money + "원 입니다.");
		// 잔돈 계산
		// 거스름돈 주기
		dao.change(mto.money);

	}
}
