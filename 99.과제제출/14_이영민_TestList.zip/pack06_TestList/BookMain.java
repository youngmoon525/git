package pack06_TestList;

import java.util.ArrayList;
import java.util.Scanner;

//도서프로그램의 시작
public class BookMain {
	public static void main(String[] args) {
		BookDAO dao = new BookDAO();
		
		ArrayList<BookDTO> list = new ArrayList<BookDTO>();
		list.add(new BookDTO("책이름1", 20000, "저자1", "출판사1"));
		list.add(new BookDTO("책이름2", 10000, "저자2", "출판사2"));
		list.add(new BookDTO("책이름3", 30000, "저자3", "출판사3"));
		System.out.println("도서 관리 프로그램을 실행합니다.");
		Scanner sc = new Scanner(System.in);
		
		
		while(true) {
			System.out.println("1.관리자모드 , 2.사용자모드");
			System.out.println("프로그램을 종료하시려면 exit를 입력하세요.");
			String check = sc.nextLine();
			if(check.equals("1")) {
				System.out.println("관리자모드로 실행합니다.");
				dao.manageBooks(list);
			}else if(check.equals("2")) {
				System.out.println("사용자모드로 실행합니다.");
				dao.userBooks(list);
			}else if(check.equals("exit")) {
				System.out.println("프로그램을 종료합니다.");
				break;
			}else {
				System.out.println("잘못 입력하였습니다. 다시 입력하세요.");
				continue;
			}
		}
	}
}
