package pack06_TestList;
//도서의 상태정보 정의
public class BookDTO {
	private String bookName; // 책 이름
	private int price; // 책 값
	private String writerName; // 저자
	private String Company; // 출판사
	
	public BookDTO(String bookName, int price, String writerName, String company) {
		
		this.bookName = bookName;
		this.price = price;
		this.writerName = writerName;
		this.Company = company;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getWriterName() {
		return writerName;
	}

	public void setWriterName(String writerName) {
		this.writerName = writerName;
	}

	public String getCompany() {
		return Company;
	}

	public void setCompany(String company) {
		Company = company;
	}
	
	
}
