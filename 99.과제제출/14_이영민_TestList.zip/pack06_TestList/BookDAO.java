package pack06_TestList;

import java.util.ArrayList;
import java.util.Scanner;

//도서의 기능을 정의
public class BookDAO {

	public void displayList(ArrayList<BookDTO> list) {

		for (int i = 0; i < list.size(); i++) {
			System.out.println(i + "번 " + list.get(i).getBookName() + "," + list.get(i).getPrice() + ","
					+ list.get(i).getWriterName() + "," + list.get(i).getCompany());
		}
	}// displayList

	public void manageBooks(ArrayList<BookDTO> list) {
		BookDAO dao = new BookDAO();
		Scanner sc = new Scanner(System.in);
		System.out.println("작업할 내용을 선택하세요.");
		System.out.println("1.책 추가 2.책 수정 3.책 삭제 4.책 검색 5.처음으로");

		while (true) {
			int check = Integer.parseInt(sc.nextLine());
			if (check == 1) {
				System.out.println("추가할 책의 이름을 입력하세요.");
				String newBookName = sc.nextLine();
				System.out.println("추가할 책의 가격을 입력하세요.");
				int newBookPrice = Integer.parseInt(sc.nextLine());
				System.out.println("추가할 책의 저자명을 입력하세요.");
				String newBookWriter = sc.nextLine();
				System.out.println("추가할 책의 출판사를 입력하세요.");
				String newBookCompany = sc.nextLine();
				list.add(new BookDTO(newBookName, newBookPrice, newBookWriter, newBookCompany));
				System.out.println("정상적으로 추가되었습니다.");
				dao.displayList(list);
				System.out.println("작업할 내용을 선택하세요.");
				System.out.println("1.책 추가 2.책 수정 3.책 삭제 4.책 검색 5.처음으로");

			} else if (check == 2) {
				System.out.println("수정할 책의 번호를 입력하세요.");
				dao.displayList(list);
				int choice = Integer.parseInt(sc.nextLine());
				System.out.println("수정할 책의 이름을 입력하세요.");
				list.get(choice).setBookName(sc.nextLine());
				System.out.println("수정할 책의 가격을 입력하세요.");
				list.get(choice).setPrice(Integer.parseInt(sc.nextLine()));
				System.out.println("수정할 책의 저자명을 입력하세요.");
				list.get(choice).setWriterName(sc.nextLine());
				System.out.println("수정할 책의 출판사를 입력하세요.");
				list.get(choice).setCompany(sc.nextLine());
				System.out.println("정상적으로 수정되었습니다.");
				dao.displayList(list);
				System.out.println("작업할 내용을 선택하세요.");
				System.out.println("1.책 추가 2.책 수정 3.책 삭제 4.책 검색 5.처음으로");

			} else if (check == 3) {
				System.out.println("삭제할 책의 번호를 입력하세요.");
				dao.displayList(list);
				int choice = Integer.parseInt(sc.nextLine());
				list.remove(choice);
				System.out.println("정상적으로 삭제되었습니다.");
				dao.displayList(list);
				System.out.println("작업할 내용을 선택하세요.");
				System.out.println("1.책 추가 2.책 수정 3.책 삭제 4.책 검색 5.처음으로");
			} else if (check == 4) {
				System.out.println("조회하실 책의 제목을 검색하세요.");
				String bookname = sc.nextLine();
				for (int i = 0; i < list.size(); i++) {
					if (bookname.equals(list.get(i).getBookName())) {
						System.out.println("조회하신 책의 결과 입니다.");
						System.out.println(i + "번 " + list.get(i).getBookName() + "," + list.get(i).getPrice() + ","
								+ list.get(i).getWriterName() + "," + list.get(i).getCompany());
					}
				}
			} else if (check == 5) {
				System.out.println("처음으로 돌아갑니다.");
				break;
			}else {
				System.out.println("잘못 입력하였습니다. 다시 입력하세요");
				System.out.println("작업할 내용을 선택하세요.");
				System.out.println("1.책 추가 2.책 수정 3.책 삭제 4.책 검색 5.처음으로");
				continue;
			}

		}
	}// manageBooks

	public void userBooks(ArrayList<BookDTO> list) {
		BookDAO dao = new BookDAO();
		while (true) {
			try {
				System.out.println("금액을 입력하세요.");
				Scanner sc = new Scanner(System.in);
				int coin = Integer.parseInt(sc.nextLine());
				int exchange = 0;
				System.out.println(coin + "원이 입력되었습니다.");
				dao.displayList(list);
				System.out.println("구입할 책의 번호를 입력하세요.");
				int choice = Integer.parseInt(sc.nextLine());
				System.out.println("구입할 책의 수량을 입력하세요.");
				int cnt = Integer.parseInt(sc.nextLine());
				try {
					
					if (cnt <= 0) {
						System.out.println("적어도 1권 이상은 구매하셔야 합니다.");
						System.out.println("1. 다시 선택하기 2.사용자모드의 처음으로 돌아가기");
						int check = Integer.parseInt(sc.nextLine());
						if(check == 1) {
							System.out.println("구입할 책의 수량을 입력하세요.");
							cnt = Integer.parseInt(sc.nextLine());
						}else if(check == 2){
							continue;
						}else {
							System.out.println("잘못 입력하였습니다. 사용자모드의 처음으로 돌아갑니다.");
							continue;
						}
							
						
						
					}
					if (coin < (list.get(choice).getPrice() * cnt)) {
						System.out.println("투입 금액이 부족합니다.");
						System.out.println("1.다시 투입하기 2.투입금액 추가하기 3.사용자모드의 처음으로 돌아가기");
						int check = Integer.parseInt(sc.nextLine());
						if(check == 1) {
							System.out.println("금액을 입력하세요.");
							coin = Integer.parseInt(sc.nextLine());
						}else if(check == 2) {
							System.out.println("추가할 금액을 입력하세요.");
							coin = coin + Integer.parseInt(sc.nextLine());
						}else if(check == 3) {
							exchange = coin;
							System.out.println("잔돈 : " + exchange);
							continue;
						}else {
							System.out.println("잘못 입력하였습니다. 사용자모드의 처음으로 돌아갑니다.");
							continue;
						}
					}
					exchange = coin - (list.get(choice).getPrice() * cnt);
					System.out.println(choice+"번 책을 "+ cnt+"권 구매하셨습니다. 처음으로 돌아갑니다.");
				} catch (Exception e) {
					System.out.println("잘못 선택하셨습니다.");
					continue;
				}
				System.out.println("잔돈 : " + exchange);
				break;

			} catch (Exception e) {
				System.out.println("잘못 입력하였습니다.");
				continue;
			}

		}
	}
}
