package homeWork01;

public class BookDTO {
	String name; //책명
	String writer; //저자
	String company;//출판사
	private int price;	//가격
	
	
	public BookDTO(String name, String writer, String company, int price) {
		super();
		this.name = name;
		this.writer = writer;
		this.company = company;
		this.price = price;
	}

	public BookDTO() {
		
	}

	public int getPrice() {
		return price;
	}

	public int setprice(int price) {
		this.price = price;
		return price;
	}


	public void name(String name) {
		this.name = name;
	}

	public void writer(String writer) {
		this.writer = writer;
	}

	public void company(String company) {
		this.company = company;
	}



	
}
