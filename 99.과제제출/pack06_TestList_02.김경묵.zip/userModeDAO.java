package homeWork01;

import java.util.ArrayList;
import java.util.Scanner;

public class userModeDAO {
	public ArrayList<BookDTO> userDisplay(ArrayList<BookDTO> list) {
		BookDAO dao = new BookDAO();
		Scanner sc = new Scanner(System.in);
		int money = 0;

		while (true) {
			System.out.println("사용자 모드");
			System.out.println("1.입금 2.도서 목록 조회 3.구매 4. 잔돈반환 ▶이 외 숫자 입력시 사용자모드 종료");
			System.out.println("잔고 : " + money + "원");
			int mode = dao.rtnInt("");
			if (mode == 1) {
				money += dao.rtnInt("현 재 잔고는 " + money + "원 입니다. 입금할 금액을 입력하세요");
				System.out.println(money + "원 입금했습니다..");
			} else if (mode == 2) { // 목록 조회
				String n = dao.rtnStr("조회할 도서 목록의 이름을 입력하세요");
				while (true) {
					String nm = dao.rtnStr("");
					for (int i = 0; i < list.size(); i++) {
						if (list.get(i).name.equals(nm)) {
							System.out.println((i + 1) + ". 제목 : " + list.get(i).name + ", 저자 : " + list.get(i).writer
									+ ", 출판사 : " + list.get(i).company + ", 가격 : " + list.get(i).getPrice() + "원");
							break;
						}
					}
				}
			} else if (mode == 3) { // 주문
				dao.display(list);
				while (true) {
					int n = dao.rtnInt("구매할 도서의 번호를 입력하세요") - 1;
					try {
						if (list.size() <= n || n <= -1) {
							System.out.println("목록에 없는 번호, 다시 입력하세요");
							throw new Exception("0이상의 수만 입력하세요!!!");
						} else {
							int choice = dao.rtnInt("다시 한번 " + (n + 1) + "번을 입력하세요");
							for (int i = 0; i < list.size(); i++) {
								int quantity = dao.rtnInt("필요한 수량을 입력하세요");
								if (choice == i + 1) {
									if (list.get(i).getPrice() <= money) {
										System.out.println(
												(i + 1) + "." + list.get(i).name + ".(" + list.get(i).getPrice() + ")");
										money -= (quantity * list.get(i).getPrice());
										System.out.println(list.get(i).name + "은(는) " + quantity + "권으로 총 "
												+ (quantity * list.get(i).getPrice()) + "원, 남은 금액 : " + money
												+ "원 입니다.");
									} else {
										System.out.println("금액이 적습니다. 돈을 더 입금하세요.");
									}
								}
								break;
							}
						}
					} catch (Exception e) {
						System.out.println(e.getMessage());
						continue;
					}
					break;
				}
			} else if (mode == 4) {
				System.out.println("잔돈을 반환하겠습니다." + money + "원");
				money -= money;
			} else {
				System.out.println("잔돈을 반환하겠습니다." + money + "원");
				money -= money;
				System.out.println("사용자모드 아웃");
				break;// 사용자모드 아웃
			} // 사용자모드 다시 실행

		} // while
		return list;
	}
}
