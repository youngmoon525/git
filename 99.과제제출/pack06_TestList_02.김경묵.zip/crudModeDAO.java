package homeWork01;

import java.util.ArrayList;
import java.util.Scanner;

public class crudModeDAO {
	public ArrayList<BookDTO> crudDisplay(ArrayList<BookDTO> list) {
		BookDAO dao = new BookDAO();
		Scanner sc = new Scanner(System.in);
		// 추가 수정 삭제 검색
		int n;
		while (true) {
			System.out.println("관리자 모드");
			System.out.println("1.목록추가 2.목록수정 3.목록삭제 4.목록검색 ▶이 외 숫자 입력시 관리자모드 종료");
			BookDTO dto = new BookDTO();
			int mode = dao.rtnInt("");
			if (mode == 1) {
				dao.display(list);
				dto.name(dao.rtnStr("도서의 제목을 입력하세요"));
				dto.writer(dao.rtnStr("도서의 저자를 입력하세요"));
				dto.company(dao.rtnStr("도서의 출판사를 입력하세요"));
				dto.setprice(dao.rtnInt("도서의 가격을 입력하세요"));
				list.add(dto);
				dao.display(list);
			} else if (mode == 2) {
				dao.display(list);
				while (true) {
					System.out.println("수정할 목록의 번호를 입력하세요");
					n = dao.rtnInt("") - 1;
					try {
						if (list.size() <= n||n<=-1) {
							System.out.println("목록에 없는 번호, 다시 입력하세요");
							throw new Exception("0이상의 수만 입력하세요!!!");
						} else {
							list.get(n).name(dao.rtnStr("제목 수정"));
							list.get(n).writer(dao.rtnStr("저자 수정"));
							list.get(n).company(dao.rtnStr("출판사 수정"));
							list.get(n).setprice(dao.rtnInt("가격 수정"));
							dao.display(list);
						}
					} catch (Exception e) {
						System.out.println(e.getMessage());					
						continue;
					}	
					break;
				}
			} else if (mode == 3) {
				dao.display(list);
				while (true) {
					System.out.println("삭제할 목록의 번호를 입력하세요");
					n = dao.rtnInt("") - 1;
					try {
						if (list.size() <= n||n<=-1) {
							System.out.println("목록에 없는 번호, 다시 입력하세요");
							throw new Exception("0이상의 수만 입력하세요!!!");
						} else {
							list.remove(n);
							dao.display(list);
							if (list.size() == 0) {
								System.out.println("서점 폐업 그 동안 사랑해주셔서 감사합니다");
							}
						}
					} catch (Exception e) {
						System.out.println(e.getMessage());					
						continue;
					}
					break;
				}
			} else if (mode == 4) {
				while (true) {
					System.out.println("검색할 목록의 번호를 입력하세요");
					n = dao.rtnInt("") - 1;
					try {
						if (list.size() <= n||n<=-1) {
							System.out.println("목록에 없는 번호, 다시 입력하세요");
							throw new Exception("0이상의 수만 입력하세요!!!");
						} else {
							for (int i = 0; i < list.size(); i++) {
								if (n == i) {
									System.out.println((i + 1) + ". 제목 : " + list.get(i).name + ", 저자 : "
											+ list.get(i).writer + ", 출판사 : " + list.get(i).company + ", 가격 : "
											+ list.get(i).getPrice());
								}
							}
						}
						
					} catch (Exception e) {
						System.out.println(e.getMessage());					
						continue;
					}
					break;
				}
			}else {
				System.out.println("나가");
				break;
			}
		}
		return list;
	}
}

// main 책 3권 정보 있는 list => cruddisplay
// 책정보 수정 책 2 , 4
// ==> main
//		 ArrayList<BookDTO> list2 = new ArrayList<>();
//		return list2;
//	}
//	public ArrayList<BookDTO> crudDisplay(String list333) {
//		 ArrayList<BookDTO> list3 = new ArrayList<>();
//		return list3;
//	}
//			//내가 다시 돌려주겠다.       //내가 받아오겠다.
//	public ArrayList<BookDTO> crudDisplay(int list) {
//
