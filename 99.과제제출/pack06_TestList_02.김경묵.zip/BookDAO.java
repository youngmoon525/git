package homeWork01;

import java.util.ArrayList;
import java.util.Scanner;

public class BookDAO {
	public void display(ArrayList<BookDTO> list) {
		for (int i = 0; i < list.size(); i++) {
			System.out.println((i+1)+". 제목 : "+list.get(i).name+", 저자 : "+list.get(i).writer+", 출판사 : "+list.get(i).company+", 가격 : "+list.get(i).getPrice()+"원");
		}
	}
	
	public String rtnStr(String msg) {
		System.out.println(msg);
		Scanner sc = new Scanner(System.in);
		while (true){
			try {
				String rtns = sc.nextLine();
				if(rtns.trim().length()>=1) {
					return rtns;
				}
			} catch (Exception e) {
				System.out.println("한글자 이상의 문자를 입력하세요");
			}
		}
	}
	
	public int rtnInt(String msg) {
		System.out.println(msg);
		Scanner sc = new Scanner(System.in);
		while (true) {
			try {
				int rtni = Integer.parseInt(sc.nextLine());
				if (rtni>=0) {
					return rtni;
				}else {
					System.out.println("양의 수를 입력하라");
					continue;
				}
			} catch (Exception e) {
				System.out.println("0이상의 숫자만 입력하세요(문자x)");
			}
		}
	}
	
}
