package homeWork01;

import java.util.ArrayList;
import java.util.Scanner;

public class BookMain {
	public static void main(String[] args) {
		System.out.println("서점에 오신걸 환영합니다");
		Scanner sc = new Scanner(System.in);
		
		ArrayList<BookDTO> list = new ArrayList<BookDTO>();
		list.add(new BookDTO("시간은 흐르지 않는다", "카를로 로벨리", "쌤앤파커스", 14400));
		list.add(new BookDTO("시간은 거꾸러 흐른다", "로벨리", "파커스", 12400));
		list.add(new BookDTO("시간은 시간이요 물은 물", "카를로", "쌤", 10400));
		
		
		BookDAO dao = new BookDAO();
		while (true) {
			String mode = dao.rtnStr("1.관리자 모드 2.손님 모드 ※종료시 'bye;입력 ▶그 외의 키 입력시 미진행");
			if (mode.equals("1")) {
				//관리자모드 1입력
				System.out.println("관리자 모드 실행");
			}else if (mode.equals("2")) {
				//손님모드 2입력
				userModeDAO ud = new userModeDAO();
				ud.userDisplay(list);
			}else if (mode.equals("bye")) {
				System.out.println("시스템 종료");
				break;
			}
				
			
		}
	}
	
	
	
}