package pack06_TestList;
import java.util.ArrayList;
import java.util.Scanner;

public class BookDAO {
	public void bookDisplay(ArrayList<BookDTO> list) {
		for (int i = 0; i < list.size(); i++) {
			System.out.println((i+1) + ". 도서 제목 : "+ list.get(i).getBookName()+ ",  저자 : " + list.get(i).getWriter()
					+ ", 출판사 :" + list.get(i).getCompany()+ ", 가격 : " + list.get(i).getPrice()+ " 원,  개수 : " +list.get(i).getAmount());
		}
		
	}//bookDisplay 보여주는거 !


	public String str() {
		Scanner sc = new Scanner(System.in);
		String str = "";
		while (true) {
			try {
				str = sc.nextLine();
				if (str.trim().length() > 0) {
					
				}
				return str;
				
			} catch (Exception e) {
				System.out.println("문자를 제대로 입력해주세요.");
			}
			
		}
	}//str

	
	public int intNum() {
		Scanner sc = new Scanner(System.in);
		while (true) {
			try {
				int num = Integer.parseInt(sc.nextLine());
				if (num > 0) {
					
					return num;
				}else {
					System.out.println(" 양의 숫자를 입력해주세요");
					
				}
			} catch (Exception e) {
				System.out.println("숫자를 제대로 입력하세요.");
			}
		}
		
	}

	
	public int intNumChoice() {
		Scanner sc = new Scanner(System.in);
		while (true) {
			try {
				int num = Integer.parseInt(sc.nextLine());
				if (num >= 0) {
					
					return num;
				}else {
					System.out.println("0 이상의 숫자를 입력해주세요");
					
				}
			} catch (Exception e) {
				System.out.println("숫자를 제대로 입력하세요.");
			}
		}
		
	}

	public String strMsg(String msg) {
		
		System.out.println(msg);
		
		return null;
	}



}//class
