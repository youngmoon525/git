package pack06_TestList;
import java.util.ArrayList;

public class BookMain {
	public static void main(String[] args) {
		
		ArrayList<BookDTO> list = new ArrayList<BookDTO>();
		list.add(new BookDTO("혼자 공부하는 자바", "신용권", "한빛 미디어", 30000,5));
		list.add(new BookDTO("과학교육론", "권재술", "교육과학사", 27000, 3));
		list.add(new BookDTO("물리교육학 총론", "김익균", "북스힐", 18000, 2));

		BookDAO dao = new BookDAO();
		// 기능 구현 시작
		System.out.println("도서 프로그램을 시작합니다.");
//		dao.bookDisplay(list); //확인
		
		while (true) {
			System.out.println("1. 관리자 모드  2.사용자 모드 (이외를 선택할 시 프로그램이 자동 종료됩니다.)");
			try {
				int a =dao.intNum();
				if (a== 1) {
					System.out.println("관리자 모드를 실행합니다.");
					masterDAO mdao= new masterDAO();
					list= mdao.masterDisplay(list);
					
					
				} else if(a==2){
					System.out.println("사용자 모드를 실행합니다.");
					UserDAO udao= new UserDAO();
					list = udao.userDisplay(list);
				} else if(!(a == 1||a==2)){
					System.out.println("프로그램을 종료합니다.");
					
					
				}
				
			} catch (Exception e) {
				// TODO: handle exception
			}
		}//while문 끝
		
		
	}//main
}//class
