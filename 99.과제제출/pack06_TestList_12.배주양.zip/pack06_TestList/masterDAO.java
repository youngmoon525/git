package pack06_TestList;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.DefaultDesktopManager;

public class masterDAO {
	public ArrayList<BookDTO> masterDisplay(ArrayList<BookDTO> list) {
		BookDAO dao = new BookDAO();
		System.out.println("1. 도서 추가 2. 도서 수정 3. 도서 삭제 4. 도서 검색");
		int num = dao.intNum();
		while (true) {
			if (num ==1) {
				System.out.println("도서 추가 모드를 실행합니다.");
				BookDTO dto= new BookDTO();
				while (true) {
					System.out.println( "Y 입력시 도서 추가 모드를 진행하고, N 입력시 도서 추가 모드를 종료합니다.");
					String str =dao.str();
					dao.bookDisplay(list);
					try {
						if (str.equals("Y")) {
							System.out.println("도서 제목을 입력해주세요.");
							dto.setBookName(dao.str());
							System.out.println("도서 저자를 입력해주세요.");
							dto.setWriter(dao.str());
							System.out.println("도서 출판사를 입력해주세요.");
							dto.setCompany(dao.str());
							System.out.println("도서 가격을 입력해주세요.");
							dto.setPrice(dao.intNum());
							System.out.println("도서 갯수를 입력해주세요.");
							dto.setAmount(dao.intNum());
							list.add(dto);
							dao.bookDisplay(list);

						} else if (str.equals("N")) {
							System.out.println("도서 추가 모드를 종료합니다.");
							break;
						}else {
							System.out.println("잘못 입력하셨습니다. Y와 N 중 하나를 입력해주세요.");
							break;
						}

					} catch (Exception e) {
						System.out.println("입력이 잘못되었습니다. 다시 입력해주세요.");
					}
				}
				
			}else if(num ==2) {
				System.out.println("도서 수정 모드를 상태입니다.");
				dao.bookDisplay(list);
				while (true) {
					System.out.println("도서 수정 모드를 진행하고 싶다면 Y , 나가고 싶다면 N를 입력해주세요.");
					String str =dao.str();
					if (str.equals("Y")) {
						System.out.println("도서 수정 모드를 실행합니다.");
						dao.bookDisplay(list);
						System.out.println("도서를 수정할 번호를 선택하세요.");
						try {
							int a = dao.intNum();
							if (list.size() < a ) {
								System.out.println("숫자를 제대로 입력해주세요.");
							}else {
								System.out.println();
								System.out.println("도서의 이름을 입력해주세요.");
								list.get((a-1)).setBookName(dao.str());
								System.out.println("도서의 저자를 입력해주세요.");
								list.get((a)-1).setWriter(dao.str());
								System.out.println("도서의 출판사를 입력해주세요.");
								list.get((a-1)).setCompany(dao.str());
								System.out.println("도서의 가격 입력해주세요.");
								list.get((a-1)).setPrice(dao.intNum());
								System.out.println("도서의 수량 입력해주세요.");
								list.get((a-1)).setAmount(dao.intNum());
								System.out.println();
								dao.bookDisplay(list);
							}
							
						} catch (Exception e) {
							System.out.println("입력이 잘못되었습니다.");
						}
						
					}
					else if (str.equals("N")) {
						System.out.println("도서 수정 모드 프로그램을 종료합니다.");
						break;
					}
					else {
						System.out.println("잘못 입력하셨습니다. Y와 N중 입력해주세요.");
						break;
					}
					
				}

			} else if (num == 3) {
				System.out.println("도서 삭제 모드를 실행합니다.");
				while (true) {
					System.out.println("계속 진행을 원하신다면 Y를 도서 삭제 모드를 종료하고 싶다면 N를 입력하세요.");
					dao.bookDisplay(list);
					String str = dao.str();
					
					try {
						if (str.equals("Y")) {
							dao.bookDisplay(list);
							System.out.println("도서를 삭제할 번호를 선택하세요.");
							list.remove(dao.intNum() - 1);
							dao.bookDisplay(list);
							System.out.println();
							
						} else if (str.equals("N")) {
							System.out.println("도서 삭제 모드를 종료합니다.");
							dao.bookDisplay(list);
							System.out.println();
							break;
						} else {
							System.out.println("잘못 입력하셨습니다. Y와 N 중 하나만 입력해주세요.");
							break;
						}

					} catch (Exception e) {
						// TODO: handle exception
					}
				}//while 문
			}else if(num==4) {
				System.out.println("도서 검색 모드를 실행합니다.");
				while (true) {
					System.out.println("도서 검색 모드 실행을 원하신다면 Y를."
							+ "\n도서 검색 모드를 종료하고 싶다면 N를 입력하세요.");
					try {
						String str = dao.str();
						if (str.equals("Y")) {
							System.out.println("찾으시는 도서의 제목을 입력해주세요.");
							for (int i = 0; i < list.size(); i++) {
								if (dao.str().equals(list.get(i).getBookName())) {
									System.out.println((i+1)+ ". 제목 : " +  list.get(i).getBookName() + ", 저자 : " + list.get(i).getWriter()+ ", 출판사 : " 
								+ list.get(i).getCompany()+", 가격 : " + list.get(i).getPrice()+ "원");
									System.out.println("확인하셨다면 Enter를 쳐주세요.");
									break;
								}
							}
						}else if(str.equals("N")) {
							System.out.println("도서 검색 모드를 종료합니다.");
							dao.bookDisplay(list);
							System.out.println();
							break;
							
						}else {
							System.out.println("잘못 입력하셨습니다. Y와 N 중 하나만을 입력해주세요.");
							break;
						}
					} catch (Exception e) {
						System.out.println("입력이 잘못되었습니다.");
					}
				}
			}else { 
				System.out.println("잘못 입력하셨습니다. 보기의 숫자를 입력해주세요.");
			}//else if문 완료
			
			
			return list;
		
		}//while문 완료
	}//display 완료
	
}//class
