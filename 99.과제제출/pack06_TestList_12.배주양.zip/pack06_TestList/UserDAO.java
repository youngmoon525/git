package pack06_TestList;
import java.util.ArrayList;

public class UserDAO {
	public ArrayList<BookDTO> userDisplay (ArrayList<BookDTO> list ){
		BookDAO dao = new BookDAO();
		BookDTO dto = new BookDTO();
		int bookAmount = 0;
		int money = 0;
		while (true) {
			System.out.println("============================================================");
			System.out.println("0. 금액 입력 1. 도서 목록 조회 2. 도서 주문 3. 잔돈 배출 ");
			System.out.println("현재 금액 :" + dto.getMoney() + "원");
			try {
				int str = dao.intNumChoice();
				if (str == 0) {
					System.out.println("금액을 입력해주세요.");
					money  += dao.intNum();
					money = dto.setMoney(money);
					System.out.println("현재 " + dto.getMoney() +" 원이 투입되어있습니다.");
					System.out.println();
				}//금액 입력
				
				
				else if (str ==1) {
					System.out.println("도서 목록 조회 모드입니다.");
					System.out.println();
					dao.bookDisplay(list);
					System.out.println();
				}// 도서 목록 조회
				
				
				else if (str==2) {

					System.out.println("도서 주문 모드입니다.");
					while (true) {
						
						System.out.println("현재  금액 : " + dto.getMoney() + " 원");
						
						System.out.println("도서 주문 모드를 계속 진행할 것이라면 A를, \n도서 주문 모드를 종료할 것이라면 B를 입력해주세요.");
						
						try {
							String order = dao.str();
							if (order.equals("A")) {
								System.out.println("도서주문 모드를 실행합니다.");
								dao.bookDisplay(list);
								System.out.println("주문하시고자 하는 책의 번호를 선택해주세요.");
								int choice = dao.intNum();
								System.out.println("수량을 입력해주세요.");
								int amount = dao.intNum();
								for (int i = 0; i < list.size(); i++) {
									if(choice >= (list.size()+1)) {
										System.out.println("주문번호를 잘못 입력하셨습니다.");
										break;
									}else {
										if (choice == (i+1) && amount <= list.get(i).getAmount() && choice <= list.size()+1) {
											System.out.println((i+1) + ". 도서 제목 : "+ list.get(i).getBookName()+ ",  저자 : " + list.get(i).getWriter()
													+ ", 출판사 :" + list.get(i).getCompany()+ ", 가격 : " + list.get(i).getPrice()+ " ,원  개수 : " +amount + "개를 결제하겠습니다.");
											System.out.println("결제를 원하시면 Y, 취소를 원하시면 N를 입력해주세요.");
											String msg = dao.str();
											if (msg.equals("Y")) {
												if ( money >= (list.get(i).getPrice()*amount)) {
													bookAmount = list.get(i).getAmount()-amount;
													list.get(i).setAmount(bookAmount);
													money -= list.get(i).getPrice()*amount;
													money = dto.setMoney(money);
													dao.bookDisplay(list);
													System.out.println("결제가 완료되었습니다. 잔액은 " + dto.getMoney() + " 원 입니다.");
												}else {
													System.out.println("잔액이 부족합니다.");
													break;
												}
											}else if (msg.equals("N")) {
												System.out.println("결제를 취소합니다.");
												break;
											}
										} else if(choice == (i+1) && amount > list.get(i).getAmount()) {
											System.out.println("구매할 수 있는 수량을 초과하였습니다.");
											break;
										} 
									}
								}
							
								
								
							} else if (order.equals("B")) {
								System.out.println("도서 주문 모드를 종료합니다.");
								break;

							} else {
								System.out.println("잘못 입력하셨습니다. A 혹은 B를 입력해주세요.");
								
							}// if
							
						} catch (Exception e) {
							System.out.println("정확히 입력해주세요.");
						}
					}
				}//도서 주문 
				else if (str==3) {
					System.out.println("잔돈 배출 모드입니다.");
					int aksdnjs;
					int dhcjsdnjs;
					int cjsdnjs;
					int dhqordnjs;
					int qordnjs;
					aksdnjs = money / 10000;
					dhcjsdnjs = (money%10000)/5000;
					cjsdnjs = ((money%10000) % 5000)/1000;
					dhqordnjs = (((money%10000) % 5000)%1000)/500;
					qordnjs = ((((money%10000) % 5000)%1000)%500)/100;
					
					System.out.println("만원 :" +aksdnjs+ " 개, 오천원 : "+ dhcjsdnjs+ " 개, 천원 : " +cjsdnjs+" 개, 오백원 : " +dhqordnjs + " 개, 백원 : " + qordnjs + " 개");
					System.out.println("잔돈을 받아가세요. ");
					System.out.println("===================================================");
					System.out.println();
							break;
					
				}//잔돈 배출
				else {
					System.out.println("숫자를 정확하게 입력해주세요.");
					
					
				}//잔돈 배출
				
			} catch (Exception e) {
				System.out.println("숫자를 정확하게 입력해주세요.");
			}
		}//while 문 종료 
		
		
		return list;	
		
	}
	
	
}
