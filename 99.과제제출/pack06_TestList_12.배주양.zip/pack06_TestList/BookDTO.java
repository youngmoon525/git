package pack06_TestList;

public class BookDTO {
	private String bookName;
	private String writer;
	private String company;
	private int price;
	private int money = 0;
	private int amount = 0;
	
	public int getAmount() {
		return amount;
	}

	public int setAmount(int amount) {
		if (amount>= 0) {
			this.amount = amount;
		}	
		return amount;
	}

	public int getMoney() {
		return money;
	}

	public int setMoney(int money) {
		if (money >0 ) {
			this.money= money;
		}else {
			System.out.println(" 0 이상의 금액을 입력해주세요.");
		}
		return money;
	}

	public BookDTO() {
		
	}
	
	public BookDTO(String bookName, String writer, String company, int price, int amount) {
		this.bookName = bookName;
		this.writer = writer;
		this.company = company;
		this.price = price;
		this.amount= amount;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public String getWriter() {
		return writer;
	}

	public void setWriter(String writer) {
		this.writer = writer;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public int getPrice() {
		return price;
	}

	public int setPrice(int price) {
		if (price > 0) {
			this.price = price;
		
			
		}
		return price;
		
	}
	
	
	
	
	
}
