package pack06_TestList;

import java.util.ArrayList;
import java.util.Scanner;

import pack05_Japangi.DrinkDAO;
import pack05_Japangi.DrinkDTO;

public class BookDAO {
	int coin = 0;
	public int rtnInt() { //리턴인트
		Scanner sc = new Scanner(System.in);
		int rtnInt = 0;
		while (true) {
			try {
				System.out.println("숫자를 입력해주세요.");
				rtnInt = Integer.parseInt(sc.nextLine());
				return rtnInt;

			} catch (Exception e) {

			}

		}
	}

	public String rtnStr() { //리턴스트링
		Scanner sc = new Scanner(System.in);
		String rtnStr = "";
		while (true) {

			rtnStr = sc.nextLine();
			if (rtnStr.trim().length() > 0) {
				return rtnStr;
			}
		}
	}
	public void display(ArrayList<BookDTO> list) { //목록
		for (int i = 0; i < list.size(); i++) {
			System.out.println("[책 제목 : " + (i+1) + "." + list.get(i).getTitle() +"] [책 저자 : " + list.get(i).getWriter() +"] [출판사 : " + list.get(i).getCompany() +"] [금액 :"+ list.get(i).getPrice()+"원]");
		}
	}
	
	public void userBook(ArrayList<BookDTO> list) { //사용자모드
		BookDAO dao = new BookDAO();
	
		int coin = 0;
		int num2 = 0;
		System.out.println("사용자 모드");
		System.out.println("0. 금액입력  1.도서 목록 조회  2.도서 주문  3.잔돈 배출");
		String inputData = dao.rtnStr();
	
		if(inputData.equals("0")) {
			System.out.println("금액을 입력해주세요.");
			coin = dao.rtnInt();
			System.out.println("1.도서 목록 조회  2.도서 주문  3.잔돈 배출");
			String inputData1 = dao.rtnStr();
			if(inputData1.equals("1")) {
				dao.display(list);
			}else if(inputData1.equals("2")) {
				dao.display(list);
				System.out.println("도서를 선택해 주세요.");
				int num1 = dao.rtnInt();
				System.out.println("주문하실 권수를 입력해 주세요");
				num2 = dao.rtnInt();
				coin = coin - (list.get(num1-1).getPrice() * num2);
				if(coin >=0) {
					System.out.println("잔돈 : "+ coin + "원");
				}else {
					System.out.println("잘못된 입력입니다.");
					
				}
				System.out.println("1.관리자 모드  2.사용자 모드 ▶ 그 외 키를 누르면 종료 됩니다.");
				
			}else if(inputData1.equals("3")) {
				System.out.println("금액을 반환 합니다"+ coin + "원");
				
			}
				
		}else if(inputData.equals("1")) {
			dao.display(list);
		}else if(inputData.equals("2")) {
			System.out.println("먼저 금액을 입력하여주세요");
			coin= dao.rtnInt();
			dao.display(list);
			System.out.println("도서를 선택해 주세요.");
			int num1 = dao.rtnInt();
			System.out.println("주문하실 권수를 입력해 주세요");
			num2 = dao.rtnInt();
			coin = coin - (list.get(num1-1).getPrice() * num2);
			if(coin >=0) {
				System.out.println("잔돈 : "+ coin + "원");
			}else {
				System.out.println("잘못된 입력입니다.");
				
			}
			System.out.println("1.관리자 모드  2.사용자 모드 ▶ 그 외 키를 누르면 종료 됩니다.");
			
		}else if(inputData.equals("3")) {
			System.out.println("금액을 반환 합니다"+ coin + "원");
			
		}
		

		
		//반복되는 코드를 찾는다. => 메소드로 나누고
	
}
	public void bookMj (ArrayList<BookDTO> list){ //관리자모드
		BookDAO dao = new BookDAO();

		
		
			System.out.println("관리자 모드 ");
			
			System.out.println("1.도서 추가 2.도서 수정 3. 도서 삭제 4.도서 검색");
			String inputData = dao.rtnStr();
			if(inputData.equals("1")) {
			
				System.out.println("도서 추가를 시작합니다.");
				BookDTO dto = new BookDTO();
			
				System.out.println("도서의 이름을 입력해주세요");
				dto.setTitle(dao.rtnStr());
				System.out.println("도서의 저자를 입력해주세요");
				dto.setWriter(dao.rtnStr());
				System.out.println("도서의 출판사를 입력해주세요");
				dto.setCompany( dao.rtnStr() ) ;
				System.out.println("도서의 가격을 입력해주세요");
				dto.setPrice( dao.rtnInt() ) ;
				list.add(dto);
				dao.display(list);
				System.out.println("1.관리자 모드  2.사용자 모드 ▶ 그 외 키를 누르면 종료 됩니다.");
			}else if(inputData.equals("2")) {
				//음료 수정 로직을 구현
				System.out.println("도서의 수정을 시작합니다");
				dao.display(list);
				System.out.println("수정할 번호를 선택 하세요");
				int num = dao.rtnInt();
				System.out.println("도서의 이름을 입력해주세요.");
				String title=dao.rtnStr();
				list.get(num-1 ).setTitle(title);
				dao.display(list);
				System.out.println("1.관리자 모드  2.사용자 모드 ▶ 그 외 키를 누르면 종료 됩니다.");
				//..반복 처리 
			}else if(inputData.equals("3")){
				//음료 삭제 로직을 구현
				System.out.println("도서의 삭제를 시작합니다");
				dao.display(list);//음료의 목록을 다시보여주고 해당하는 번호를 선택하게끔 유도
				System.out.println("삭제할 번호를 선택 하세요");
				list.remove( dao.rtnInt()-1 ) ;//음료 삭제 완료
				dao.display(list);
				System.out.println("1.관리자 모드  2.사용자 모드 ▶ 그 외 키를 누르면 종료 됩니다.");
		
			}else if(inputData.equals("4")) {
				BookDTO dto = new BookDTO();
				System.out.println("도서 검색을 시작합니다");
				System.out.println("찾으시는 책 제목을 입력하세요");
				String inputData1 = dao.rtnStr();
				for (int i = 0; i < list.size(); i++) {
					
					if(inputData1.equals(list.get(i).getTitle())){
						System.out.println("[책 제목 : " + (i+1) + "." + list.get(i).getTitle() +"] [책 저자 : " + list.get(i).getWriter() +"] [출판사 : " + list.get(i).getCompany() +"] [금액 :"+ list.get(i).getPrice()+"원]");
					}else {
						System.out.println("찾으시는 책이 없습니다.");
						break;
					}
				}
				System.out.println("1.관리자 모드  2.사용자 모드 ▶ 그 외 키를 누르면 종료 됩니다.");
			}
		
	}



}


