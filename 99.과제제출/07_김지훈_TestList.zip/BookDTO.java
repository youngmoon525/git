package pack06_TestList;

public class BookDTO {
	private String title;
	private String writer;
	private String company;
	private int price;
	
	public BookDTO() {}
	
	public BookDTO(String title, String writer, String company, int price) {
	
		this.title = title;
		this.writer = writer;
		this.company = company;
		this.price = price;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getWriter() {
		return writer;
	}

	public void setWriter(String writer) {
		this.writer = writer;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

}
