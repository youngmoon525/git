package pack06_TestList;

import java.util.ArrayList;

public class BookMain {
	public static void main(String[] args) {
		BookDAO dao = new BookDAO();
		System.out.println("도서 관리 프로그램을 시작합니다.");
		System.out.println("1.관리자모드 2.사용자모드  ▶그 외의 키를 누르면 종료됩니다.");
		ArrayList<BookDTO> list = new ArrayList<BookDTO>();
		list.add(new BookDTO("왕좌의게임", "조지 R.R 마틴", "은행나무", 15000));
		list.add(new BookDTO("반지의 제왕", "J.R.R. 톨킨", "아르테", 30000));
		list.add(new BookDTO("왜 나는 너를 사랑하는가", "알랭 드 보통", "청미래", 10000));
		while(true){
			String inputData = dao.rtnStr();			
			if(inputData.equals("1") ) {
			dao.bookMj(list);
		}else if(inputData.equals("2")) {
			
			dao.userBook(list);
			
		}else {
			System.out.println("종료됩니다");
			break;
		}}
	}
}
