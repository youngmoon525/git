package pack06_TestList;

import java.util.ArrayList;
import java.util.Scanner;

public class BookDAO {
	public void display(ArrayList<BookDTO> list) {
		for (int i = 0; i < list.size(); i++) {
			System.out.println(list.get(i).getNumber() + ". " + list.get(i).getName() + ", " + list.get(i).getWriter()
					+ ", " + list.get(i).getCompany() + ", " + list.get(i).getPrice());
		}
	}
	
	public int rtnInt() {
		Scanner sc = new Scanner(System.in);
		int rtni = 0;
		while(true) {
			try {
			rtni = Integer.parseInt(sc.nextLine());
			return rtni;
			}catch (Exception e) {
				System.out.println("잘못된 입력입니다.");
			}
		}
	}
	
	public String rtnStr() {
		Scanner sc = new Scanner(System.in);
		String rtns = "";
		while(true) {
				rtns = sc.nextLine();
				if (rtns.trim().length()>0) {
					return rtns;
				} 
			} 
	}
	
	public int amonut() {
		Scanner sc = new Scanner(System.in);
		int rtna = 0;
		rtna = Integer.parseInt(sc.nextLine());
		return rtna;
		
	}
}
