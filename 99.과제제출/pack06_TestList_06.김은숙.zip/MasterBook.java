package pack06_TestList;

import java.util.ArrayList;

public class MasterBook {
	public ArrayList<BookDTO> masterBook(ArrayList<BookDTO> list) {
		BookDAO dao = new BookDAO();
		BookDTO dto = new BookDTO();
		System.out.println("관리자 모드를 시작합니다.");
		System.out.println("1. 도서 추가, 2. 도서 수정, 3. 도서 삭제 4. 도서 검색");
		String inputData = dao.rtnStr();

		if (inputData.equals("1")) {
			System.out.println("도서 추가를 시작합니다.");
			System.out.println("추가할 도서의 번호를 입력해주세요.");
			dto.setNumber(dao.rtnInt());
			System.out.println("추가할 도서의 이름을 입력해주세요.");
			dto.setName(dao.rtnStr());
			System.out.println("추가할 도서의 저자를 입력해주세요.");
			dto.setWriter(dao.rtnStr());
			System.out.println("추가할 도서의 출판사를 입력해주세요.");
			dto.setCompany(dao.rtnStr());
			System.out.println("추가할 도서의 가격을 입력해주세요.");
			dto.setPrice(dao.rtnInt());
			list.add(dto);
			dao.display(list);
		} else if (inputData.equals("2")) {
			System.out.println("도서 수정을 시작합니다.");
			dao.display(list);
			System.out.println("수정 할 도서를 선택해주세요.");
				int num = dao.rtnInt() - 1;
				try {
					System.out.println("도서의 이름을 입력해주세요.");
					list.get(num).setName(dao.rtnStr());
					dao.display(list);
					System.out.println("도서의 저자를 입력해주세요.");
					list.get(num).setWriter(dao.rtnStr());
					dao.display(list);
					System.out.println("도서의 출판사를 입력해주세요.");
					list.get(num).setCompany(dao.rtnStr());
					dao.display(list);
					System.out.println("도서의 가격을 입력해주세요.");
					list.get(num).setPrice(dao.rtnInt());
					dao.display(list);
				} catch (Exception e) {
					System.out.println(e.getMessage());
				}
		} else if (inputData.equals("3")) {
			System.out.println("도서 삭제를 시작합니다.");
			dao.display(list);
			System.out.println("삭제 할 도서를 선택해주세요.");
			list.remove(dao.rtnInt() - 1);
			dao.display(list);
		} else if (inputData.equals("4")) {
			System.out.println("조회하고 싶은 도서의 번호를 입력해주세요.");
			int inputNum = dao.rtnInt() - 1;
			for (int i = 0; i < list.size(); i++) {
				if (inputNum == list.get(i).getNumber()) {
					System.out.println("도서이름 : " + list.get(i).getName());
					System.out.println("도서저자 : " + list.get(i).getWriter());
					System.out.println("도서회사 : " + list.get(i).getCompany());
					System.out.println("도서가격 : " + list.get(i).getPrice());
				} 
			}
		} else {
			System.out.println("잘못된 입력입니다.");
		}

		return list;

	}
}
