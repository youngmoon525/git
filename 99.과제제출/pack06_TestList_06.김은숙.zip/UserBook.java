package pack06_TestList;

import java.util.ArrayList;

public class UserBook {
	int coin;
	int money;

	public void userBook(ArrayList<BookDTO> list) {
		BookDAO dao = new BookDAO();
		BookDTO dto = new BookDTO();

		System.out.println("사용자 모드를 시작합니다.");
		System.out.println("금액을 입력해주세요.");
		coin = dao.rtnInt();
		System.out.println("현재 금액은 " + coin + "원 입니다.");
		System.out.println("1. 도서 목록 조회 2. 도서 주문 3. 잔돈 반환");
		int n = dao.rtnInt();
		try {
			if (n == 1) {
				dao.display(list);
			} else if (n == 2) {
				dao.display(list);
				System.out.println("주문할 도서를 선택해주세요.");

				int num = dao.rtnInt() - 1;
				if (coin >= list.get(num).getPrice()) {
					coin = coin - list.get(num).getPrice();
					System.out.println("선택한 도서는 " + list.get(num).getName() + "입니다.");
					System.out.println("잔돈은 " + coin + "원 입니다.");
					System.out.println("추가 주문을 원하면 Y를, 종료하시려면 N을 입력해주세요.");
				} else if (coin < list.get(num).getPrice()) {
					System.out.println("금액이 부족합니다.");
				}

				String order = dao.rtnStr();
				if (order.equals("Y")) {
					System.out.println("추가로 주문할 도서의 번호를 입력해주세요.");
					dao.rtnInt();
					System.out.println("추가로 주문할 권 수를 입력해주세요.");
					int amount = dao.amonut();
					System.out.println("추가로 주문할 도서는 " + list.get(num).getName() + "이며, 추가로 주문할 도서의 수는 " + amount + "권 입니다.");

					money = list.get(num).getPrice() * amount;
					System.out.println("주문한 도서는" + list.get(num).getName() + "이며 총 " + amount + "권 으로 " + money + "입니다.");
					System.out.println("주문이 성공적으로 완료 되었습니다. 감사합니다.");

				} else if (order.equals("N")) {
					System.out.println("주문이 성공적으로 완료 되었습니다. 감사합니다.");
					System.out.println("잔돈은 " + coin + "원 입니다.");
				}
			} else if(n == 3) {
				System.out.println("잔돈은 " + coin + "원 입니다.");
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
}
