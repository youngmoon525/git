package pack06_TestList;

public class BookDTO {
	private String name;
	private String writer;
	private String company;
	private int price;
	private int number;
	private int amount;	
	
	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public BookDTO() {
		
	}

	public BookDTO(int number, String name, String writer, String company, int price) {
		this.number = number;
		this.name = name;
		this.writer = writer;
		this.company = company;
		this.price = price;
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getWriter() {
		return writer;
	}

	public void setWriter(String writer) {
		this.writer = writer;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}
}
