package pack06_TestList;

import java.util.ArrayList;

public class BookMain {
	public static void main(String[] args) {
		ArrayList<BookDTO> list = new ArrayList<>();
		list.add(new BookDTO(1, "혼자 공부하는 자바", "신용권", "한빛미디어", 30000));
		list.add(new BookDTO(2, "고독한 산책자의 몽상", "장자크 루소", "문학동네", 11500));
		list.add(new BookDTO(3, "이방인", "알베르 카뮈", "반니", 8000));
		list.add(new BookDTO(4, "데미안", "헤르만 헤세", "문학동네", 8000));
		
		BookDAO dao = new BookDAO();
		
		System.out.println("환영합니다.");
		System.out.println("1. 관리자 모드 2. 사용자 모드 ▶ 종료를 원하시면 exit를 입력해 주세요.");
		
		while(true) {
			String inputData = dao.rtnStr();
			if (inputData.equals("1")) {
				MasterBook mb = new MasterBook();
				mb.masterBook(list);
				
			} else if(inputData.equals("2")) {
				UserBook ub = new UserBook();
				ub.userBook(list);
			}else if(inputData.equals("exit")){
				System.out.println("종료되었습니다.");
				break;
			}else {
				System.out.println("잘못된 입력입니다.");
			}
			
		}
	}
}
