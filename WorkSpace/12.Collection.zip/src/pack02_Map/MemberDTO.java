package pack02_Map;

public class MemberDTO {
	String name;
	int age;
	public MemberDTO(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}
	
}
